package com.carrentalsystem.ui;

import com.carrentalsystem.dao.CarDAO;
import com.carrentalsystem.model.Car;
import com.carrentalsystem.util.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.List;

/**
 * Panel for managing cars in the system
 */
public class CarManagementPanel extends JPanel {
    
    private CarDAO carDAO;
    private JTable carTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton refreshButton;
    
    /**
     * Constructor
     */
    public CarManagementPanel() {
        carDAO = new CarDAO();
        
        setLayout(new BorderLayout());
        setBackground(UIUtils.LIGHT_COLOR);
        
        initializeUI();
        loadCarData();
    }
    
    /**
     * Initialize the UI components
     */
    private void initializeUI() {
        // Title panel
        JPanel titlePanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel titleLabel = UIUtils.createLabel("Car Management", UIUtils.FONT_TITLE);
        titlePanel.add(titleLabel);
        
        // Search panel
        JPanel searchPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel searchLabel = UIUtils.createLabel("Search:", UIUtils.FONT_REGULAR);
        searchField = UIUtils.createTextField(20);
        JButton searchButton = UIUtils.createButton("Search", UIUtils.PRIMARY_COLOR);
        
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.RIGHT));
        addButton = UIUtils.createButton("Add Car", UIUtils.SUCCESS_COLOR);
        editButton = UIUtils.createButton("Edit Car", UIUtils.WARNING_COLOR);
        deleteButton = UIUtils.createButton("Delete Car", UIUtils.DANGER_COLOR);
        refreshButton = UIUtils.createButton("Refresh", UIUtils.INFO_COLOR);
        
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Top panel (combines title, search, and buttons)
        JPanel topPanel = UIUtils.createPanel(new BorderLayout());
        topPanel.add(titlePanel, BorderLayout.NORTH);
        topPanel.add(searchPanel, BorderLayout.WEST);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        
        // Table panel
        JPanel tablePanel = UIUtils.createPanel(new BorderLayout());
        
        // Create table model with columns
        String[] columns = {"ID", "Make", "Model", "Year", "Registration", "Color", "Daily Rate", "Status", "Category", "Mileage"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        carTable = UIUtils.createTable();
        carTable.setModel(tableModel);
        
        // Scroll pane for table
        JScrollPane scrollPane = new JScrollPane(carTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add panels to main panel
        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        
        // Set up event listeners
        setupListeners();
    }
    
    /**
     * Set up event listeners
     */
    private void setupListeners() {
        // Add car button
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddCarDialog();
            }
        });
        
        // Edit car button
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = carTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int carId = (int) carTable.getValueAt(selectedRow, 0);
                    Car car = carDAO.getCarById(carId);
                    if (car != null) {
                        showEditCarDialog(car);
                    }
                } else {
                    UIUtils.showErrorMessage(CarManagementPanel.this, "Please select a car to edit.");
                }
            }
        });
        
        // Delete car button
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = carTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int carId = (int) carTable.getValueAt(selectedRow, 0);
                    if (UIUtils.showConfirmDialog(CarManagementPanel.this, "Are you sure you want to delete this car?")) {
                        if (carDAO.deleteCar(carId)) {
                            loadCarData(); // Refresh table
                            UIUtils.showInfoMessage(CarManagementPanel.this, "Car deleted successfully.");
                        } else {
                            UIUtils.showErrorMessage(CarManagementPanel.this, "Failed to delete car.");
                        }
                    }
                } else {
                    UIUtils.showErrorMessage(CarManagementPanel.this, "Please select a car to delete.");
                }
            }
        });
        
        // Refresh button
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadCarData();
            }
        });
    }
    
    /**
     * Load car data from the database into the table
     */
    private void loadCarData() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Get all cars from the database
        List<Car> cars = carDAO.getAllCars();
        
        // Add cars to the table model
        for (Car car : cars) {
            Object[] rowData = {
                car.getCarId(),
                car.getMake(),
                car.getModel(),
                car.getYear(),
                car.getRegistrationNumber(),
                car.getColor(),
                UIUtils.CURRENCY_FORMATTER.format(car.getDailyRate()),
                car.getStatus(),
                car.getCategory(),
                car.getMileage()
            };
            tableModel.addRow(rowData);
        }
    }
    
    /**
     * Show dialog to add a new car
     */
    public void showAddCarDialog() {
        // Create a dialog
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Add New Car", true);
        dialog.setSize(400, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Make
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(UIUtils.createLabel("Make:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        JTextField makeField = UIUtils.createTextField(15);
        formPanel.add(makeField, gbc);
        
        // Model
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(UIUtils.createLabel("Model:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JTextField modelField = UIUtils.createTextField(15);
        formPanel.add(modelField, gbc);
        
        // Year
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(UIUtils.createLabel("Year:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField yearField = UIUtils.createTextField(15);
        formPanel.add(yearField, gbc);
        
        // Registration Number
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(UIUtils.createLabel("Registration Number:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField regNumberField = UIUtils.createTextField(15);
        formPanel.add(regNumberField, gbc);
        
        // Color
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(UIUtils.createLabel("Color:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField colorField = UIUtils.createTextField(15);
        formPanel.add(colorField, gbc);
        
        // Daily Rate
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(UIUtils.createLabel("Daily Rate ($):", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField rateField = UIUtils.createTextField(15);
        formPanel.add(rateField, gbc);
        
        // Status
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(UIUtils.createLabel("Status:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 6;
        String[] statuses = {"AVAILABLE", "RENTED", "MAINTENANCE"};
        JComboBox<String> statusComboBox = UIUtils.createComboBox(statuses);
        formPanel.add(statusComboBox, gbc);
        
        // Category
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(UIUtils.createLabel("Category:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 7;
        String[] categories = {"ECONOMY", "COMPACT", "MID_SIZE", "FULL_SIZE", "SUV", "LUXURY"};
        JComboBox<String> categoryComboBox = UIUtils.createComboBox(categories);
        formPanel.add(categoryComboBox, gbc);
        
        // Mileage
        gbc.gridx = 0;
        gbc.gridy = 8;
        formPanel.add(UIUtils.createLabel("Mileage:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 8;
        JTextField mileageField = UIUtils.createTextField(15);
        formPanel.add(mileageField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveButton = UIUtils.createButton("Save", UIUtils.SUCCESS_COLOR);
        JButton cancelButton = UIUtils.createButton("Cancel", UIUtils.DANGER_COLOR);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate input
                    String make = makeField.getText().trim();
                    String model = modelField.getText().trim();
                    int year = Integer.parseInt(yearField.getText().trim());
                    String regNumber = regNumberField.getText().trim();
                    String color = colorField.getText().trim();
                    BigDecimal rate = new BigDecimal(rateField.getText().trim());
                    String status = (String) statusComboBox.getSelectedItem();
                    String category = (String) categoryComboBox.getSelectedItem();
                    int mileage = Integer.parseInt(mileageField.getText().trim());
                    
                    if (make.isEmpty() || model.isEmpty() || regNumber.isEmpty() || color.isEmpty()) {
                        UIUtils.showErrorMessage(dialog, "Please fill in all fields.");
                        return;
                    }
                    
                    // Create car object
                    Car car = new Car(make, model, year, regNumber, color, rate, status, category, mileage, null);
                    
                    // Add car to database
                    int carId = carDAO.addCar(car);
                    
                    if (carId > 0) {
                        loadCarData(); // Refresh table
                        dialog.dispose();
                        UIUtils.showInfoMessage(CarManagementPanel.this, "Car added successfully.");
                    } else {
                        UIUtils.showErrorMessage(dialog, "Failed to add car.");
                    }
                    
                } catch (NumberFormatException ex) {
                    UIUtils.showErrorMessage(dialog, "Please enter valid numeric values for Year, Daily Rate, and Mileage.");
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        dialog.setVisible(true);
    }
    
    /**
     * Show dialog to edit an existing car
     * @param car The car to edit
     */
    private void showEditCarDialog(Car car) {
        // Create a dialog
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Car", true);
        dialog.setSize(400, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Make
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(UIUtils.createLabel("Make:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        JTextField makeField = UIUtils.createTextField(15);
        makeField.setText(car.getMake());
        formPanel.add(makeField, gbc);
        
        // Model
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(UIUtils.createLabel("Model:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JTextField modelField = UIUtils.createTextField(15);
        modelField.setText(car.getModel());
        formPanel.add(modelField, gbc);
        
        // Year
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(UIUtils.createLabel("Year:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField yearField = UIUtils.createTextField(15);
        yearField.setText(String.valueOf(car.getYear()));
        formPanel.add(yearField, gbc);
        
        // Registration Number
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(UIUtils.createLabel("Registration Number:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField regNumberField = UIUtils.createTextField(15);
        regNumberField.setText(car.getRegistrationNumber());
        formPanel.add(regNumberField, gbc);
        
        // Color
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(UIUtils.createLabel("Color:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField colorField = UIUtils.createTextField(15);
        colorField.setText(car.getColor());
        formPanel.add(colorField, gbc);
        
        // Daily Rate
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(UIUtils.createLabel("Daily Rate ($):", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField rateField = UIUtils.createTextField(15);
        rateField.setText(car.getDailyRate().toString());
        formPanel.add(rateField, gbc);
        
        // Status
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(UIUtils.createLabel("Status:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 6;
        String[] statuses = {"AVAILABLE", "RENTED", "MAINTENANCE"};
        JComboBox<String> statusComboBox = UIUtils.createComboBox(statuses);
        statusComboBox.setSelectedItem(car.getStatus());
        formPanel.add(statusComboBox, gbc);
        
        // Category
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(UIUtils.createLabel("Category:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 7;
        String[] categories = {"ECONOMY", "COMPACT", "MID_SIZE", "FULL_SIZE", "SUV", "LUXURY"};
        JComboBox<String> categoryComboBox = UIUtils.createComboBox(categories);
        categoryComboBox.setSelectedItem(car.getCategory());
        formPanel.add(categoryComboBox, gbc);
        
        // Mileage
        gbc.gridx = 0;
        gbc.gridy = 8;
        formPanel.add(UIUtils.createLabel("Mileage:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 8;
        JTextField mileageField = UIUtils.createTextField(15);
        mileageField.setText(String.valueOf(car.getMileage()));
        formPanel.add(mileageField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveButton = UIUtils.createButton("Save", UIUtils.SUCCESS_COLOR);
        JButton cancelButton = UIUtils.createButton("Cancel", UIUtils.DANGER_COLOR);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Validate input
                    String make = makeField.getText().trim();
                    String model = modelField.getText().trim();
                    int year = Integer.parseInt(yearField.getText().trim());
                    String regNumber = regNumberField.getText().trim();
                    String color = colorField.getText().trim();
                    BigDecimal rate = new BigDecimal(rateField.getText().trim());
                    String status = (String) statusComboBox.getSelectedItem();
                    String category = (String) categoryComboBox.getSelectedItem();
                    int mileage = Integer.parseInt(mileageField.getText().trim());
                    
                    if (make.isEmpty() || model.isEmpty() || regNumber.isEmpty() || color.isEmpty()) {
                        UIUtils.showErrorMessage(dialog, "Please fill in all fields.");
                        return;
                    }
                    
                    // Update car object
                    car.setMake(make);
                    car.setModel(model);
                    car.setYear(year);
                    car.setRegistrationNumber(regNumber);
                    car.setColor(color);
                    car.setDailyRate(rate);
                    car.setStatus(status);
                    car.setCategory(category);
                    car.setMileage(mileage);
                    
                    // Update car in database
                    boolean success = carDAO.updateCar(car);
                    
                    if (success) {
                        loadCarData(); // Refresh table
                        dialog.dispose();
                        UIUtils.showInfoMessage(CarManagementPanel.this, "Car updated successfully.");
                    } else {
                        UIUtils.showErrorMessage(dialog, "Failed to update car.");
                    }
                    
                } catch (NumberFormatException ex) {
                    UIUtils.showErrorMessage(dialog, "Please enter valid numeric values for Year, Daily Rate, and Mileage.");
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        dialog.setVisible(true);
    }
}