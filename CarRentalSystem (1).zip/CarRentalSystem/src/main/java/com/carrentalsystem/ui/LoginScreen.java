package com.carrentalsystem.ui;

import com.carrentalsystem.dao.UserDAO;
import com.carrentalsystem.model.User;
import com.carrentalsystem.util.UIUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Login screen for the car rental system
 */
public class LoginScreen extends JFrame {
    
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton exitButton;
    
    private UserDAO userDAO;
    
    /**
     * Constructor
     */
    public LoginScreen() {
        userDAO = new UserDAO();
        
        initializeUI();
        setupListeners();
    }
    
    /**
     * Initialize the UI components
     */
    private void initializeUI() {
        setTitle("Car Rental System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Main panel
        JPanel mainPanel = UIUtils.createPanel(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = UIUtils.createLabel("Car Rental System", UIUtils.FONT_TITLE);
        titlePanel.add(titleLabel);
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Username
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel usernameLabel = UIUtils.createLabel("Username:", UIUtils.FONT_REGULAR);
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        usernameField = UIUtils.createTextField(15);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel passwordLabel = UIUtils.createLabel("Password:", UIUtils.FONT_REGULAR);
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        passwordField = new JPasswordField(15);
        passwordField.setFont(UIUtils.FONT_REGULAR);
        formPanel.add(passwordField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        loginButton = UIUtils.createButton("Login", UIUtils.PRIMARY_COLOR);
        exitButton = UIUtils.createButton("Exit", UIUtils.DANGER_COLOR);
        buttonPanel.add(loginButton);
        buttonPanel.add(exitButton);
        
        // Add panels to main panel
        mainPanel.add(titlePanel, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Set content pane
        setContentPane(mainPanel);
    }
    
    /**
     * Set up event listeners
     */
    private void setupListeners() {
        // Login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
        
        // Exit button
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        // Allow login with Enter key
        passwordField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });
    }
    
    /**
     * Attempt to log in with the provided credentials
     */
    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        
        if (username.isEmpty() || password.isEmpty()) {
            UIUtils.showErrorMessage(this, "Please enter both username and password.");
            return;
        }
        
        // Check if we're in mock mode
        if (com.carrentalsystem.util.DatabaseConnection.isMockMode()) {
            // In mock mode, accept any login with non-empty username/password
            // Create a mock user
            User user = new User();
            user.setUserId(1);
            user.setUsername(username);
            user.setRole("ADMIN"); // Give admin role in mock mode
            
            // Login successful
            MainScreen mainScreen = new MainScreen(user);
            mainScreen.setVisible(true);
            dispose(); // Close login screen
            return;
        }
        
        // Normal database authentication
        User user = userDAO.authenticateUser(username, password);
        
        if (user != null) {
            // Login successful
            MainScreen mainScreen = new MainScreen(user);
            mainScreen.setVisible(true);
            dispose(); // Close login screen
        } else {
            // Login failed
            UIUtils.showErrorMessage(this, "Invalid username or password.");
            passwordField.setText("");
        }
    }
    
    /**
     * Main method to start the application
     */
    public static void main(String[] args) {
        try {
            // Set system look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginScreen().setVisible(true);
            }
        });
    }
}