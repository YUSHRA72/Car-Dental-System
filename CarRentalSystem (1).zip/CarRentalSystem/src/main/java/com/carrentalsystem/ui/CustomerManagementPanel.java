package com.carrentalsystem.ui;

import com.carrentalsystem.dao.CustomerDAO;
import com.carrentalsystem.model.Customer;
import com.carrentalsystem.util.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 * Panel for managing customers in the system
 */
public class CustomerManagementPanel extends JPanel {
    
    private CustomerDAO customerDAO;
    private JTable customerTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JButton refreshButton;
    
    /**
     * Constructor
     */
    public CustomerManagementPanel() {
        customerDAO = new CustomerDAO();
        
        setLayout(new BorderLayout());
        setBackground(UIUtils.LIGHT_COLOR);
        
        initializeUI();
        loadCustomerData();
    }
    
    /**
     * Initialize the UI components
     */
    private void initializeUI() {
        // Title panel
        JPanel titlePanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel titleLabel = UIUtils.createLabel("Customer Management", UIUtils.FONT_TITLE);
        titlePanel.add(titleLabel);
        
        // Search panel
        JPanel searchPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel searchLabel = UIUtils.createLabel("Search:", UIUtils.FONT_REGULAR);
        searchField = UIUtils.createTextField(20);
        JButton searchButton = UIUtils.createButton("Search", UIUtils.PRIMARY_COLOR);
        
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.RIGHT));
        addButton = UIUtils.createButton("Add Customer", UIUtils.SUCCESS_COLOR);
        editButton = UIUtils.createButton("Edit Customer", UIUtils.WARNING_COLOR);
        deleteButton = UIUtils.createButton("Delete Customer", UIUtils.DANGER_COLOR);
        refreshButton = UIUtils.createButton("Refresh", UIUtils.INFO_COLOR);
        
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(refreshButton);
        
        // Top panel (combines title, search, and buttons)
        JPanel topPanel = UIUtils.createPanel(new BorderLayout());
        topPanel.add(titlePanel, BorderLayout.NORTH);
        topPanel.add(searchPanel, BorderLayout.WEST);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        
        // Table panel
        JPanel tablePanel = UIUtils.createPanel(new BorderLayout());
        
        // Create table model with columns
        String[] columns = {"ID", "First Name", "Last Name", "Email", "Phone", "Address", "Driver License", "Registration Date"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        customerTable = UIUtils.createTable();
        customerTable.setModel(tableModel);
        
        // Scroll pane for table
        JScrollPane scrollPane = new JScrollPane(customerTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add panels to main panel
        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        
        // Set up event listeners
        setupListeners();
    }
    
    /**
     * Set up event listeners
     */
    private void setupListeners() {
        // Add customer button
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddCustomerDialog();
            }
        });
        
        // Edit customer button
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = customerTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int customerId = (int) customerTable.getValueAt(selectedRow, 0);
                    Customer customer = customerDAO.getCustomerById(customerId);
                    if (customer != null) {
                        showEditCustomerDialog(customer);
                    }
                } else {
                    UIUtils.showErrorMessage(CustomerManagementPanel.this, "Please select a customer to edit.");
                }
            }
        });
        
        // Delete customer button
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = customerTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int customerId = (int) customerTable.getValueAt(selectedRow, 0);
                    if (UIUtils.showConfirmDialog(CustomerManagementPanel.this, "Are you sure you want to delete this customer?")) {
                        if (customerDAO.deleteCustomer(customerId)) {
                            loadCustomerData(); // Refresh table
                            UIUtils.showInfoMessage(CustomerManagementPanel.this, "Customer deleted successfully.");
                        } else {
                            UIUtils.showErrorMessage(CustomerManagementPanel.this, "Failed to delete customer.");
                        }
                    }
                } else {
                    UIUtils.showErrorMessage(CustomerManagementPanel.this, "Please select a customer to delete.");
                }
            }
        });
        
        // Refresh button
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadCustomerData();
            }
        });
        
        // Search button
        searchField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchCustomers();
            }
        });
    }
    
    /**
     * Load customer data from the database into the table
     */
    private void loadCustomerData() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Get all customers from the database
        List<Customer> customers = customerDAO.getAllCustomers();
        
        // Add customers to the table model
        for (Customer customer : customers) {
            Object[] rowData = {
                customer.getCustomerId(),
                customer.getFirstName(),
                customer.getLastName(),
                customer.getEmail(),
                customer.getPhone(),
                customer.getAddress(),
                customer.getDriverLicense(),
                customer.getRegistrationDate() != null ? UIUtils.formatDateTime(customer.getRegistrationDate()) : ""
            };
            tableModel.addRow(rowData);
        }
    }
    
    /**
     * Search for customers by name
     */
    private void searchCustomers() {
        String searchTerm = searchField.getText().trim();
        
        if (searchTerm.isEmpty()) {
            loadCustomerData(); // If search term is empty, load all customers
            return;
        }
        
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Search customers by name
        List<Customer> customers = customerDAO.searchCustomersByName(searchTerm);
        
        // Add matching customers to the table model
        for (Customer customer : customers) {
            Object[] rowData = {
                customer.getCustomerId(),
                customer.getFirstName(),
                customer.getLastName(),
                customer.getEmail(),
                customer.getPhone(),
                customer.getAddress(),
                customer.getDriverLicense(),
                customer.getRegistrationDate() != null ? UIUtils.formatDateTime(customer.getRegistrationDate()) : ""
            };
            tableModel.addRow(rowData);
        }
    }
    
    /**
     * Show dialog to add a new customer
     */
    public void showAddCustomerDialog() {
        // Create a dialog
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Add New Customer", true);
        dialog.setSize(400, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // First Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(UIUtils.createLabel("First Name:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        JTextField firstNameField = UIUtils.createTextField(15);
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(UIUtils.createLabel("Last Name:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JTextField lastNameField = UIUtils.createTextField(15);
        formPanel.add(lastNameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(UIUtils.createLabel("Email:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField emailField = UIUtils.createTextField(15);
        formPanel.add(emailField, gbc);
        
        // Phone
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(UIUtils.createLabel("Phone:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField phoneField = UIUtils.createTextField(15);
        formPanel.add(phoneField, gbc);
        
        // Address
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(UIUtils.createLabel("Address:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField addressField = UIUtils.createTextField(15);
        formPanel.add(addressField, gbc);
        
        // Driver License
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(UIUtils.createLabel("Driver License:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField licenseField = UIUtils.createTextField(15);
        formPanel.add(licenseField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveButton = UIUtils.createButton("Save", UIUtils.SUCCESS_COLOR);
        JButton cancelButton = UIUtils.createButton("Cancel", UIUtils.DANGER_COLOR);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validate input
                String firstName = firstNameField.getText().trim();
                String lastName = lastNameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String address = addressField.getText().trim();
                String license = licenseField.getText().trim();
                
                if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || 
                    phone.isEmpty() || address.isEmpty() || license.isEmpty()) {
                    UIUtils.showErrorMessage(dialog, "Please fill in all fields.");
                    return;
                }
                
                // Create customer object
                Customer customer = new Customer(firstName, lastName, email, phone, address, license);
                
                // Add customer to database
                int customerId = customerDAO.addCustomer(customer);
                
                if (customerId > 0) {
                    loadCustomerData(); // Refresh table
                    dialog.dispose();
                    UIUtils.showInfoMessage(CustomerManagementPanel.this, "Customer added successfully.");
                } else {
                    UIUtils.showErrorMessage(dialog, "Failed to add customer.");
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        dialog.setVisible(true);
    }
    
    /**
     * Show dialog to edit an existing customer
     * @param customer The customer to edit
     */
    private void showEditCustomerDialog(Customer customer) {
        // Create a dialog
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Customer", true);
        dialog.setSize(400, 450);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // First Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(UIUtils.createLabel("First Name:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        JTextField firstNameField = UIUtils.createTextField(15);
        firstNameField.setText(customer.getFirstName());
        formPanel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(UIUtils.createLabel("Last Name:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JTextField lastNameField = UIUtils.createTextField(15);
        lastNameField.setText(customer.getLastName());
        formPanel.add(lastNameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(UIUtils.createLabel("Email:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField emailField = UIUtils.createTextField(15);
        emailField.setText(customer.getEmail());
        formPanel.add(emailField, gbc);
        
        // Phone
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(UIUtils.createLabel("Phone:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField phoneField = UIUtils.createTextField(15);
        phoneField.setText(customer.getPhone());
        formPanel.add(phoneField, gbc);
        
        // Address
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(UIUtils.createLabel("Address:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField addressField = UIUtils.createTextField(15);
        addressField.setText(customer.getAddress());
        formPanel.add(addressField, gbc);
        
        // Driver License
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(UIUtils.createLabel("Driver License:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField licenseField = UIUtils.createTextField(15);
        licenseField.setText(customer.getDriverLicense());
        formPanel.add(licenseField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JButton saveButton = UIUtils.createButton("Save", UIUtils.SUCCESS_COLOR);
        JButton cancelButton = UIUtils.createButton("Cancel", UIUtils.DANGER_COLOR);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validate input
                String firstName = firstNameField.getText().trim();
                String lastName = lastNameField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String address = addressField.getText().trim();
                String license = licenseField.getText().trim();
                
                if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || 
                    phone.isEmpty() || address.isEmpty() || license.isEmpty()) {
                    UIUtils.showErrorMessage(dialog, "Please fill in all fields.");
                    return;
                }
                
                // Update customer object
                customer.setFirstName(firstName);
                customer.setLastName(lastName);
                customer.setEmail(email);
                customer.setPhone(phone);
                customer.setAddress(address);
                customer.setDriverLicense(license);
                
                // Update customer in database
                boolean success = customerDAO.updateCustomer(customer);
                
                if (success) {
                    loadCustomerData(); // Refresh table
                    dialog.dispose();
                    UIUtils.showInfoMessage(CustomerManagementPanel.this, "Customer updated successfully.");
                } else {
                    UIUtils.showErrorMessage(dialog, "Failed to update customer.");
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        dialog.setVisible(true);
    }
}