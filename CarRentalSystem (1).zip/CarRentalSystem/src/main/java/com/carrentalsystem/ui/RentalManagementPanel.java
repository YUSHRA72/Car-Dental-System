package com.carrentalsystem.ui;

import com.carrentalsystem.dao.CarDAO;
import com.carrentalsystem.dao.CustomerDAO;
import com.carrentalsystem.dao.RentalDAO;
import com.carrentalsystem.model.Car;
import com.carrentalsystem.model.Customer;
import com.carrentalsystem.model.Rental;
import com.carrentalsystem.util.UIUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * Panel for managing rentals in the system
 */
public class RentalManagementPanel extends JPanel {
    
    private RentalDAO rentalDAO;
    private CustomerDAO customerDAO;
    private CarDAO carDAO;
    private JTable rentalTable;
    private DefaultTableModel tableModel;
    private JComboBox<String> statusFilterComboBox;
    private JButton addButton;
    private JButton editButton;
    private JButton completeButton;
    private JButton cancelButton;
    private JButton refreshButton;
    
    /**
     * Constructor
     */
    public RentalManagementPanel() {
        rentalDAO = new RentalDAO();
        customerDAO = new CustomerDAO();
        carDAO = new CarDAO();
        
        setLayout(new BorderLayout());
        setBackground(UIUtils.LIGHT_COLOR);
        
        initializeUI();
        loadRentalData();
    }
    
    /**
     * Initialize the UI components
     */
    private void initializeUI() {
        // Title panel
        JPanel titlePanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel titleLabel = UIUtils.createLabel("Rental Management", UIUtils.FONT_TITLE);
        titlePanel.add(titleLabel);
        
        // Filter panel
        JPanel filterPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel filterLabel = UIUtils.createLabel("Filter by Status:", UIUtils.FONT_REGULAR);
        String[] statusOptions = {"All", "ACTIVE", "COMPLETED", "CANCELLED"};
        statusFilterComboBox = UIUtils.createComboBox(statusOptions);
        
        filterPanel.add(filterLabel);
        filterPanel.add(statusFilterComboBox);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.RIGHT));
        addButton = UIUtils.createButton("New Rental", UIUtils.SUCCESS_COLOR);
        editButton = UIUtils.createButton("Edit Rental", UIUtils.WARNING_COLOR);
        completeButton = UIUtils.createButton("Complete Rental", UIUtils.INFO_COLOR);
        cancelButton = UIUtils.createButton("Cancel Rental", UIUtils.DANGER_COLOR);
        refreshButton = UIUtils.createButton("Refresh", UIUtils.PRIMARY_COLOR);
        
        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(completeButton);
        buttonPanel.add(cancelButton);
        buttonPanel.add(refreshButton);
        
        // Top panel (combines title, filter, and buttons)
        JPanel topPanel = UIUtils.createPanel(new BorderLayout());
        topPanel.add(titlePanel, BorderLayout.NORTH);
        topPanel.add(filterPanel, BorderLayout.WEST);
        topPanel.add(buttonPanel, BorderLayout.EAST);
        
        // Table panel
        JPanel tablePanel = UIUtils.createPanel(new BorderLayout());
        
        // Create table model with columns
        String[] columns = {"ID", "Customer", "Car", "Start Date", "End Date", "Total Cost", "Status", "Created At"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
        };
        
        rentalTable = UIUtils.createTable();
        rentalTable.setModel(tableModel);
        
        // Scroll pane for table
        JScrollPane scrollPane = new JScrollPane(rentalTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Add panels to main panel
        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        
        // Set up event listeners
        setupListeners();
    }
    
    /**
     * Set up event listeners
     */
    private void setupListeners() {
        // Add rental button
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showAddRentalDialog();
            }
        });
        
        // Edit rental button
        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = rentalTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int rentalId = (int) rentalTable.getValueAt(selectedRow, 0);
                    Rental rental = rentalDAO.getRentalById(rentalId);
                    if (rental != null) {
                        if (rental.getStatus().equals("ACTIVE")) {
                            showEditRentalDialog(rental);
                        } else {
                            UIUtils.showErrorMessage(RentalManagementPanel.this, 
                                "Only active rentals can be edited.");
                        }
                    }
                } else {
                    UIUtils.showErrorMessage(RentalManagementPanel.this, "Please select a rental to edit.");
                }
            }
        });
        
        // Complete rental button
        completeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = rentalTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int rentalId = (int) rentalTable.getValueAt(selectedRow, 0);
                    Rental rental = rentalDAO.getRentalById(rentalId);
                    if (rental != null) {
                        if (rental.getStatus().equals("ACTIVE")) {
                            if (UIUtils.showConfirmDialog(RentalManagementPanel.this, 
                                    "Are you sure you want to complete this rental?")) {
                                rental.setStatus("COMPLETED");
                                if (rentalDAO.updateRental(rental)) {
                                    loadRentalData(); // Refresh table
                                    UIUtils.showInfoMessage(RentalManagementPanel.this, 
                                        "Rental completed successfully.");
                                } else {
                                    UIUtils.showErrorMessage(RentalManagementPanel.this, 
                                        "Failed to complete rental.");
                                }
                            }
                        } else {
                            UIUtils.showErrorMessage(RentalManagementPanel.this, 
                                "Only active rentals can be completed.");
                        }
                    }
                } else {
                    UIUtils.showErrorMessage(RentalManagementPanel.this, "Please select a rental to complete.");
                }
            }
        });
        
        // Cancel rental button
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = rentalTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int rentalId = (int) rentalTable.getValueAt(selectedRow, 0);
                    Rental rental = rentalDAO.getRentalById(rentalId);
                    if (rental != null) {
                        if (rental.getStatus().equals("ACTIVE")) {
                            if (UIUtils.showConfirmDialog(RentalManagementPanel.this, 
                                    "Are you sure you want to cancel this rental?")) {
                                rental.setStatus("CANCELLED");
                                if (rentalDAO.updateRental(rental)) {
                                    loadRentalData(); // Refresh table
                                    UIUtils.showInfoMessage(RentalManagementPanel.this, 
                                        "Rental cancelled successfully.");
                                } else {
                                    UIUtils.showErrorMessage(RentalManagementPanel.this, 
                                        "Failed to cancel rental.");
                                }
                            }
                        } else {
                            UIUtils.showErrorMessage(RentalManagementPanel.this, 
                                "Only active rentals can be cancelled.");
                        }
                    }
                } else {
                    UIUtils.showErrorMessage(RentalManagementPanel.this, "Please select a rental to cancel.");
                }
            }
        });
        
        // Refresh button
        refreshButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadRentalData();
            }
        });
        
        // Status filter
        statusFilterComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadRentalData();
            }
        });
    }
    
    /**
     * Load rental data from the database into the table
     */
    private void loadRentalData() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Get rentals from the database
        List<Rental> rentals = rentalDAO.getAllRentals();
        
        // Filter by status if needed
        String selectedStatus = (String) statusFilterComboBox.getSelectedItem();
        if (selectedStatus != null && !selectedStatus.equals("All")) {
            rentals.removeIf(rental -> !rental.getStatus().equals(selectedStatus));
        }
        
        // Add rentals to the table model
        for (Rental rental : rentals) {
            Object[] rowData = {
                rental.getRentalId(),
                rental.getCustomerName(),
                rental.getCarDetails(),
                UIUtils.formatDateTime(rental.getStartDate()),
                UIUtils.formatDateTime(rental.getEndDate()),
                UIUtils.CURRENCY_FORMATTER.format(rental.getTotalCost()),
                rental.getStatus(),
                UIUtils.formatDateTime(rental.getCreatedAt())
            };
            tableModel.addRow(rowData);
        }
    }
    
    /**
     * Show dialog to add a new rental
     */
    public void showAddRentalDialog() {
        // Get available cars
        List<Car> availableCars = carDAO.getAvailableCars();
        if (availableCars.isEmpty()) {
            UIUtils.showErrorMessage(this, "No cars available for rent.");
            return;
        }
        
        // Get all customers
        List<Customer> customers = customerDAO.getAllCustomers();
        if (customers.isEmpty()) {
            UIUtils.showErrorMessage(this, "No customers in the system. Please add a customer first.");
            return;
        }
        
        // Create a dialog
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "New Rental", true);
        dialog.setSize(500, 500);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Customer
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(UIUtils.createLabel("Customer:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        JComboBox<Customer> customerComboBox = new JComboBox<>();
        for (Customer customer : customers) {
            customerComboBox.addItem(customer);
        }
        customerComboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
                                                         boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Customer) {
                    setText(((Customer) value).getFullName());
                }
                return this;
            }
        });
        formPanel.add(customerComboBox, gbc);
        
        // Car
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(UIUtils.createLabel("Car:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JComboBox<Car> carComboBox = new JComboBox<>();
        for (Car car : availableCars) {
            carComboBox.addItem(car);
        }
        carComboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, 
                                                         boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Car) {
                    Car car = (Car) value;
                    setText(car.getYear() + " " + car.getMake() + " " + car.getModel() + 
                           " (" + car.getRegistrationNumber() + ")");
                }
                return this;
            }
        });
        formPanel.add(carComboBox, gbc);
        
        // Daily Rate
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(UIUtils.createLabel("Daily Rate:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField rateField = UIUtils.createTextField(15);
        rateField.setEditable(false);
        if (!availableCars.isEmpty()) {
            rateField.setText(UIUtils.CURRENCY_FORMATTER.format(availableCars.get(0).getDailyRate()));
        }
        formPanel.add(rateField, gbc);
        
        // Start Date
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(UIUtils.createLabel("Start Date (YYYY-MM-DD):", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField startDateField = UIUtils.createTextField(15);
        startDateField.setText(LocalDate.now().toString());
        formPanel.add(startDateField, gbc);
        
        // End Date
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(UIUtils.createLabel("End Date (YYYY-MM-DD):", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField endDateField = UIUtils.createTextField(15);
        endDateField.setText(LocalDate.now().plusDays(1).toString());
        formPanel.add(endDateField, gbc);
        
        // Total Cost
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(UIUtils.createLabel("Total Cost:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField totalCostField = UIUtils.createTextField(15);
        totalCostField.setEditable(false);
        if (!availableCars.isEmpty()) {
            totalCostField.setText(UIUtils.CURRENCY_FORMATTER.format(availableCars.get(0).getDailyRate()));
        }
        formPanel.add(totalCostField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JButton calculateButton = UIUtils.createButton("Calculate Cost", UIUtils.INFO_COLOR);
        JButton saveButton = UIUtils.createButton("Save", UIUtils.SUCCESS_COLOR);
        JButton cancelButton = UIUtils.createButton("Cancel", UIUtils.DANGER_COLOR);
        buttonPanel.add(calculateButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Car combo box action
        carComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Car selectedCar = (Car) carComboBox.getSelectedItem();
                if (selectedCar != null) {
                    rateField.setText(UIUtils.CURRENCY_FORMATTER.format(selectedCar.getDailyRate()));
                    // Recalculate total cost
                    calculateButton.doClick();
                }
            }
        });
        
        // Calculate button action
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Car selectedCar = (Car) carComboBox.getSelectedItem();
                    if (selectedCar == null) {
                        UIUtils.showErrorMessage(dialog, "Please select a car.");
                        return;
                    }
                    
                    LocalDate startDate = LocalDate.parse(startDateField.getText().trim());
                    LocalDate endDate = LocalDate.parse(endDateField.getText().trim());
                    
                    if (endDate.isBefore(startDate)) {
                        UIUtils.showErrorMessage(dialog, "End date cannot be before start date.");
                        return;
                    }
                    
                    long days = ChronoUnit.DAYS.between(startDate, endDate);
                    if (days < 1) {
                        days = 1; // Minimum 1 day rental
                    }
                    
                    BigDecimal dailyRate = selectedCar.getDailyRate();
                    BigDecimal totalCost = dailyRate.multiply(BigDecimal.valueOf(days));
                    
                    totalCostField.setText(UIUtils.CURRENCY_FORMATTER.format(totalCost));
                    
                } catch (Exception ex) {
                    UIUtils.showErrorMessage(dialog, "Please enter valid dates in YYYY-MM-DD format.");
                }
            }
        });
        
        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    Customer selectedCustomer = (Customer) customerComboBox.getSelectedItem();
                    Car selectedCar = (Car) carComboBox.getSelectedItem();
                    
                    if (selectedCustomer == null || selectedCar == null) {
                        UIUtils.showErrorMessage(dialog, "Please select both a customer and a car.");
                        return;
                    }
                    
                    LocalDate startDate = LocalDate.parse(startDateField.getText().trim());
                    LocalDate endDate = LocalDate.parse(endDateField.getText().trim());
                    
                    if (endDate.isBefore(startDate)) {
                        UIUtils.showErrorMessage(dialog, "End date cannot be before start date.");
                        return;
                    }
                    
                    // Calculate total cost
                    long days = ChronoUnit.DAYS.between(startDate, endDate);
                    if (days < 1) {
                        days = 1; // Minimum 1 day rental
                    }
                    
                    BigDecimal dailyRate = selectedCar.getDailyRate();
                    BigDecimal totalCost = dailyRate.multiply(BigDecimal.valueOf(days));
                    
                    // Create rental object
                    Rental rental = new Rental();
                    rental.setCustomerId(selectedCustomer.getCustomerId());
                    rental.setCarId(selectedCar.getCarId());
                    rental.setStartDate(LocalDateTime.of(startDate, LocalTime.of(12, 0))); // Noon on start date
                    rental.setEndDate(LocalDateTime.of(endDate, LocalTime.of(12, 0))); // Noon on end date
                    rental.setTotalCost(totalCost);
                    rental.setStatus("ACTIVE");
                    
                    // Add rental to database
                    int rentalId = rentalDAO.addRental(rental);
                    
                    if (rentalId > 0) {
                        loadRentalData(); // Refresh table
                        dialog.dispose();
                        UIUtils.showInfoMessage(RentalManagementPanel.this, "Rental created successfully.");
                    } else {
                        UIUtils.showErrorMessage(dialog, "Failed to create rental.");
                    }
                    
                } catch (Exception ex) {
                    UIUtils.showErrorMessage(dialog, "Please enter valid information in all fields.");
                    ex.printStackTrace();
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        dialog.setVisible(true);
    }
    
    /**
     * Show dialog to edit an existing rental
     * @param rental The rental to edit
     */
    private void showEditRentalDialog(Rental rental) {
        // Create a dialog
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Edit Rental", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        
        // Get customer and car details
        Customer customer = customerDAO.getCustomerById(rental.getCustomerId());
        Car car = carDAO.getCarById(rental.getCarId());
        
        if (customer == null || car == null) {
            UIUtils.showErrorMessage(this, "Error loading rental details.");
            return;
        }
        
        // Form panel
        JPanel formPanel = UIUtils.createPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Customer (non-editable)
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(UIUtils.createLabel("Customer:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        JTextField customerField = UIUtils.createTextField(20);
        customerField.setText(customer.getFullName());
        customerField.setEditable(false);
        formPanel.add(customerField, gbc);
        
        // Car (non-editable)
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(UIUtils.createLabel("Car:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JTextField carField = UIUtils.createTextField(20);
        carField.setText(car.getYear() + " " + car.getMake() + " " + car.getModel());
        carField.setEditable(false);
        formPanel.add(carField, gbc);
        
        // Daily Rate (non-editable)
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(UIUtils.createLabel("Daily Rate:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField rateField = UIUtils.createTextField(15);
        rateField.setText(UIUtils.CURRENCY_FORMATTER.format(car.getDailyRate()));
        rateField.setEditable(false);
        formPanel.add(rateField, gbc);
        
        // Start Date
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(UIUtils.createLabel("Start Date (YYYY-MM-DD):", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField startDateField = UIUtils.createTextField(15);
        startDateField.setText(rental.getStartDate().toLocalDate().toString());
        formPanel.add(startDateField, gbc);
        
        // End Date
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(UIUtils.createLabel("End Date (YYYY-MM-DD):", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField endDateField = UIUtils.createTextField(15);
        endDateField.setText(rental.getEndDate().toLocalDate().toString());
        formPanel.add(endDateField, gbc);
        
        // Total Cost
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(UIUtils.createLabel("Total Cost:", UIUtils.FONT_REGULAR), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField totalCostField = UIUtils.createTextField(15);
        totalCostField.setText(UIUtils.CURRENCY_FORMATTER.format(rental.getTotalCost()));
        totalCostField.setEditable(false);
        formPanel.add(totalCostField, gbc);
        
        // Button panel
        JPanel buttonPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        JButton calculateButton = UIUtils.createButton("Calculate Cost", UIUtils.INFO_COLOR);
        JButton saveButton = UIUtils.createButton("Save", UIUtils.SUCCESS_COLOR);
        JButton cancelButton = UIUtils.createButton("Cancel", UIUtils.DANGER_COLOR);
        buttonPanel.add(calculateButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        
        // Add panels to dialog
        dialog.add(formPanel, BorderLayout.CENTER);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        // Calculate button action
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    LocalDate startDate = LocalDate.parse(startDateField.getText().trim());
                    LocalDate endDate = LocalDate.parse(endDateField.getText().trim());
                    
                    if (endDate.isBefore(startDate)) {
                        UIUtils.showErrorMessage(dialog, "End date cannot be before start date.");
                        return;
                    }
                    
                    long days = ChronoUnit.DAYS.between(startDate, endDate);
                    if (days < 1) {
                        days = 1; // Minimum 1 day rental
                    }
                    
                    BigDecimal dailyRate = car.getDailyRate();
                    BigDecimal totalCost = dailyRate.multiply(BigDecimal.valueOf(days));
                    
                    totalCostField.setText(UIUtils.CURRENCY_FORMATTER.format(totalCost));
                    
                } catch (Exception ex) {
                    UIUtils.showErrorMessage(dialog, "Please enter valid dates in YYYY-MM-DD format.");
                }
            }
        });
        
        // Save button action
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    LocalDate startDate = LocalDate.parse(startDateField.getText().trim());
                    LocalDate endDate = LocalDate.parse(endDateField.getText().trim());
                    
                    if (endDate.isBefore(startDate)) {
                        UIUtils.showErrorMessage(dialog, "End date cannot be before start date.");
                        return;
                    }
                    
                    // Calculate total cost
                    long days = ChronoUnit.DAYS.between(startDate, endDate);
                    if (days < 1) {
                        days = 1; // Minimum 1 day rental
                    }
                    
                    BigDecimal dailyRate = car.getDailyRate();
                    BigDecimal totalCost = dailyRate.multiply(BigDecimal.valueOf(days));
                    
                    // Update rental object
                    rental.setStartDate(LocalDateTime.of(startDate, LocalTime.of(12, 0))); // Noon on start date
                    rental.setEndDate(LocalDateTime.of(endDate, LocalTime.of(12, 0))); // Noon on end date
                    rental.setTotalCost(totalCost);
                    
                    // Update rental in database
                    boolean success = rentalDAO.updateRental(rental);
                    
                    if (success) {
                        loadRentalData(); // Refresh table
                        dialog.dispose();
                        UIUtils.showInfoMessage(RentalManagementPanel.this, "Rental updated successfully.");
                    } else {
                        UIUtils.showErrorMessage(dialog, "Failed to update rental.");
                    }
                    
                } catch (Exception ex) {
                    UIUtils.showErrorMessage(dialog, "Please enter valid dates in YYYY-MM-DD format.");
                }
            }
        });
        
        // Cancel button action
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dialog.dispose();
            }
        });
        
        dialog.setVisible(true);
    }
}