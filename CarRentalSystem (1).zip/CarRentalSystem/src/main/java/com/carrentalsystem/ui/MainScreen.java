package com.carrentalsystem.ui;

import com.carrentalsystem.model.User;
import com.carrentalsystem.util.UIUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Main screen of the car rental system
 */
public class MainScreen extends JFrame {
    
    private User currentUser;
    private JTabbedPane tabbedPane;
    
    // Panels for different sections
    private JPanel dashboardPanel;
    private CarManagementPanel carManagementPanel;
    private CustomerManagementPanel customerManagementPanel;
    private RentalManagementPanel rentalManagementPanel;
    private JPanel userManagementPanel;
    
    /**
     * Constructor
     * @param user The logged-in user
     */
    public MainScreen(User user) {
        this.currentUser = user;
        
        initializeUI();
        setupListeners();
    }
    
    /**
     * Initialize the UI components
     */
    private void initializeUI() {
        setTitle("Car Rental System - Main");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Main panel
        JPanel mainPanel = UIUtils.createPanel(new BorderLayout());
        
        // Header panel
        JPanel headerPanel = createHeaderPanel();
        
        // Tabbed pane for different sections
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(UIUtils.FONT_SUBTITLE);
        
        // Create panels for each section
        dashboardPanel = createDashboardPanel();
        carManagementPanel = new CarManagementPanel();
        customerManagementPanel = new CustomerManagementPanel();
        rentalManagementPanel = new RentalManagementPanel();
        
        // Add tabs
        tabbedPane.addTab("Dashboard", new ImageIcon(), dashboardPanel);
        tabbedPane.addTab("Cars", new ImageIcon(), carManagementPanel);
        tabbedPane.addTab("Customers", new ImageIcon(), customerManagementPanel);
        tabbedPane.addTab("Rentals", new ImageIcon(), rentalManagementPanel);
        
        // Add User Management tab for admin users only
        if (currentUser.getRole().equals("ADMIN")) {
            userManagementPanel = createUserManagementPanel();
            tabbedPane.addTab("Users", new ImageIcon(), userManagementPanel);
        }
        
        // Add components to main panel
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Footer panel
        JPanel footerPanel = createFooterPanel();
        mainPanel.add(footerPanel, BorderLayout.SOUTH);
        
        // Set content pane
        setContentPane(mainPanel);
    }
    
    /**
     * Create the header panel
     * @return The header panel
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = UIUtils.createPanel(new BorderLayout());
        headerPanel.setBackground(UIUtils.PRIMARY_COLOR);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        
        // Title
        JLabel titleLabel = new JLabel("Car Rental System");
        titleLabel.setFont(UIUtils.FONT_TITLE);
        titleLabel.setForeground(Color.WHITE);
        
        // User info and logout
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        userPanel.setOpaque(false);
        
        JLabel userLabel = new JLabel("Logged in as: " + currentUser.getUsername() + " (" + currentUser.getRole() + ")");
        userLabel.setFont(UIUtils.FONT_REGULAR);
        userLabel.setForeground(Color.WHITE);
        
        JButton logoutButton = UIUtils.createButton("Logout", UIUtils.DANGER_COLOR);
        
        userPanel.add(userLabel);
        userPanel.add(logoutButton);
        
        // Add components to header panel
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(userPanel, BorderLayout.EAST);
        
        // Logout button action
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });
        
        return headerPanel;
    }
    
    /**
     * Create the dashboard panel
     * @return The dashboard panel
     */
    private JPanel createDashboardPanel() {
        JPanel panel = UIUtils.createPanel(new BorderLayout());
        
        // Welcome message
        JPanel welcomePanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel welcomeLabel = UIUtils.createLabel("Welcome to the Car Rental System, " + 
                                                currentUser.getUsername() + "!", UIUtils.FONT_TITLE);
        welcomePanel.add(welcomeLabel);
        
        // Dashboard content
        JPanel contentPanel = UIUtils.createPanel(new GridLayout(2, 2, 15, 15));
        
        // Available Cars panel
        JPanel availableCarsPanel = createDashboardCard("Available Cars", "0", UIUtils.INFO_COLOR);
        
        // Active Rentals panel
        JPanel activeRentalsPanel = createDashboardCard("Active Rentals", "0", UIUtils.SUCCESS_COLOR);
        
        // Total Customers panel
        JPanel totalCustomersPanel = createDashboardCard("Total Customers", "0", UIUtils.WARNING_COLOR);
        
        // Total Revenue panel
        JPanel totalRevenuePanel = createDashboardCard("Total Revenue", "$0.00", UIUtils.PRIMARY_COLOR);
        
        contentPanel.add(availableCarsPanel);
        contentPanel.add(activeRentalsPanel);
        contentPanel.add(totalCustomersPanel);
        contentPanel.add(totalRevenuePanel);
        
        // Quick Actions panel
        JPanel actionsPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER, 15, 0));
        
        JButton newRentalButton = UIUtils.createButton("New Rental", UIUtils.SUCCESS_COLOR);
        JButton newCustomerButton = UIUtils.createButton("New Customer", UIUtils.WARNING_COLOR);
        JButton newCarButton = UIUtils.createButton("New Car", UIUtils.INFO_COLOR);
        
        actionsPanel.add(newRentalButton);
        actionsPanel.add(newCustomerButton);
        actionsPanel.add(newCarButton);
        
        // Add components to panel
        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        panel.add(actionsPanel, BorderLayout.SOUTH);
        
        // Button actions
        newRentalButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tabbedPane.setSelectedComponent(rentalManagementPanel);
                rentalManagementPanel.showAddRentalDialog();
            }
        });
        
        newCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tabbedPane.setSelectedComponent(customerManagementPanel);
                customerManagementPanel.showAddCustomerDialog();
            }
        });
        
        newCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tabbedPane.setSelectedComponent(carManagementPanel);
                carManagementPanel.showAddCarDialog();
            }
        });
        
        return panel;
    }
    
    /**
     * Create a dashboard card panel
     * @param title The card title
     * @param value The card value
     * @param color The card color
     * @return The card panel
     */
    private JPanel createDashboardCard(String title, String value, Color color) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(color, 2));
        
        // Title
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(color);
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(UIUtils.FONT_BOLD);
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);
        
        // Value
        JPanel valuePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        valuePanel.setBackground(Color.WHITE);
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 36));
        valueLabel.setForeground(color);
        valuePanel.add(valueLabel);
        
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(valuePanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    /**
     * Create the user management panel
     * @return The user management panel
     */
    private JPanel createUserManagementPanel() {
        JPanel panel = UIUtils.createPanel(new BorderLayout());
        
        // Title
        JPanel titlePanel = UIUtils.createPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel titleLabel = UIUtils.createLabel("User Management", UIUtils.FONT_TITLE);
        titlePanel.add(titleLabel);
        
        // Content panel (placeholder for now)
        JPanel contentPanel = UIUtils.createPanel(new BorderLayout());
        JLabel contentLabel = UIUtils.createLabel("User management functionality will be implemented here.", UIUtils.FONT_REGULAR);
        contentPanel.add(contentLabel, BorderLayout.CENTER);
        
        panel.add(titlePanel, BorderLayout.NORTH);
        panel.add(contentPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    /**
     * Create the footer panel
     * @return The footer panel
     */
    private JPanel createFooterPanel() {
        JPanel footerPanel = UIUtils.createPanel(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setBackground(UIUtils.DARK_COLOR);
        
        JLabel copyrightLabel = new JLabel("© 2025 Car Rental System. All rights reserved.");
        copyrightLabel.setFont(UIUtils.FONT_REGULAR);
        copyrightLabel.setForeground(Color.WHITE);
        
        footerPanel.add(copyrightLabel);
        
        return footerPanel;
    }
    
    /**
     * Set up event listeners
     */
    private void setupListeners() {
        // Add any additional listeners here
    }
    
    /**
     * Log out and return to the login screen
     */
    private void logout() {
        if (UIUtils.showConfirmDialog(this, "Are you sure you want to log out?")) {
            LoginScreen loginScreen = new LoginScreen();
            loginScreen.setVisible(true);
            dispose(); // Close main screen
        }
    }
    
    /**
     * Refresh the dashboard data
     */
    public void refreshDashboard() {
        // This method will be implemented to update dashboard statistics
    }
}