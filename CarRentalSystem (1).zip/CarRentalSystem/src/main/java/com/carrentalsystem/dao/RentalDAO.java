package com.carrentalsystem.dao;

import com.carrentalsystem.model.Rental;
import com.carrentalsystem.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Rental entity
 */
public class RentalDAO {
    
    /**
     * Add a new rental to the database
     * @param rental The rental object to add
     * @return The ID of the newly added rental, or -1 if operation failed
     */
    public int addRental(Rental rental) {
        String sql = "INSERT INTO rentals (customer_id, car_id, start_date, end_date, total_cost, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, rental.getCustomerId());
            pstmt.setInt(2, rental.getCarId());
            pstmt.setTimestamp(3, Timestamp.valueOf(rental.getStartDate()));
            pstmt.setTimestamp(4, Timestamp.valueOf(rental.getEndDate()));
            pstmt.setBigDecimal(5, rental.getTotalCost());
            pstmt.setString(6, rental.getStatus());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        // Update car status to RENTED
                        updateCarStatus(rental.getCarId(), "RENTED");
                        return rs.getInt(1);
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error adding rental: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1;
    }
    
    /**
     * Update an existing rental in the database
     * @param rental The rental object with updated information
     * @return true if the update was successful, false otherwise
     */
    public boolean updateRental(Rental rental) {
        String sql = "UPDATE rentals SET customer_id = ?, car_id = ?, start_date = ?, " +
                    "end_date = ?, total_cost = ?, status = ? WHERE rental_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, rental.getCustomerId());
            pstmt.setInt(2, rental.getCarId());
            pstmt.setTimestamp(3, Timestamp.valueOf(rental.getStartDate()));
            pstmt.setTimestamp(4, Timestamp.valueOf(rental.getEndDate()));
            pstmt.setBigDecimal(5, rental.getTotalCost());
            pstmt.setString(6, rental.getStatus());
            pstmt.setInt(7, rental.getRentalId());
            
            int affectedRows = pstmt.executeUpdate();
            
            // If status changed to COMPLETED or CANCELLED, update car status to AVAILABLE
            if (affectedRows > 0 && 
                (rental.getStatus().equals("COMPLETED") || rental.getStatus().equals("CANCELLED"))) {
                updateCarStatus(rental.getCarId(), "AVAILABLE");
            }
            
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating rental: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Delete a rental from the database
     * @param rentalId The ID of the rental to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteRental(int rentalId) {
        // First, get the rental to know which car to update
        Rental rental = getRentalById(rentalId);
        if (rental == null) {
            return false;
        }
        
        String sql = "DELETE FROM rentals WHERE rental_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, rentalId);
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                // Update car status to AVAILABLE
                updateCarStatus(rental.getCarId(), "AVAILABLE");
                return true;
            }
            
            return false;
            
        } catch (SQLException e) {
            System.err.println("Error deleting rental: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Get a rental by its ID
     * @param rentalId The ID of the rental to retrieve
     * @return The rental object if found, null otherwise
     */
    public Rental getRentalById(int rentalId) {
        // Check if we're in mock mode
        if (com.carrentalsystem.util.DatabaseConnection.isMockMode()) {
            // Find the rental in our mock data
            List<Rental> allRentals = getAllRentals();
            
            for (Rental rental : allRentals) {
                if (rental.getRentalId() == rentalId) {
                    return rental;
                }
            }
            
            return null;
        }
        
        // Normal database access
        String sql = "SELECT r.*, " +
                    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
                    "CONCAT(ca.year, ' ', ca.make, ' ', ca.model) AS car_details " +
                    "FROM rentals r " +
                    "JOIN customers c ON r.customer_id = c.customer_id " +
                    "JOIN cars ca ON r.car_id = ca.car_id " +
                    "WHERE r.rental_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, rentalId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return extractRentalFromResultSet(rs);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting rental by ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Get all rentals from the database
     * @return A list of all rentals
     */
    public List<Rental> getAllRentals() {
        List<Rental> rentals = new ArrayList<>();
        
        // Check if we're in mock mode
        if (com.carrentalsystem.util.DatabaseConnection.isMockMode()) {
            // Return mock data
            System.out.println("MOCK MODE: Returning sample rental data");
            
            // Add some sample rentals
            LocalDateTime now = LocalDateTime.now();
            
            // Active rental
            Rental rental1 = new Rental(1, 1, 1, now.minusDays(2), 
                    now.plusDays(3), new BigDecimal("225.00"), "ACTIVE", now.minusDays(2));
            rental1.setCustomerName("John Doe");
            rental1.setCarDetails("2022 Toyota Corolla");
            rentals.add(rental1);
            
            // Completed rental
            Rental rental2 = new Rental(2, 2, 2, now.minusDays(10), 
                    now.minusDays(5), new BigDecimal("250.00"), "COMPLETED", now.minusDays(10));
            rental2.setCustomerName("Jane Smith");
            rental2.setCarDetails("2021 Honda Civic");
            rentals.add(rental2);
            
            // Cancelled rental
            Rental rental3 = new Rental(3, 3, 3, now.minusDays(15), 
                    now.minusDays(10), new BigDecimal("375.00"), "CANCELLED", now.minusDays(15));
            rental3.setCustomerName("Michael Johnson");
            rental3.setCarDetails("2023 Ford Explorer");
            rentals.add(rental3);
            
            return rentals;
        }
        
        // Normal database access
        String sql = "SELECT r.*, " +
                    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
                    "CONCAT(ca.year, ' ', ca.make, ' ', ca.model) AS car_details " +
                    "FROM rentals r " +
                    "JOIN customers c ON r.customer_id = c.customer_id " +
                    "JOIN cars ca ON r.car_id = ca.car_id " +
                    "ORDER BY r.created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                rentals.add(extractRentalFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all rentals: " + e.getMessage());
            e.printStackTrace();
        }
        
        return rentals;
    }
    
    /**
     * Get active rentals (rentals with status 'ACTIVE')
     * @return A list of active rentals
     */
    public List<Rental> getActiveRentals() {
        // Check if we're in mock mode
        if (com.carrentalsystem.util.DatabaseConnection.isMockMode()) {
            // Filter the getAllRentals result for ACTIVE rentals
            List<Rental> allRentals = getAllRentals();
            List<Rental> activeRentals = new ArrayList<>();
            
            for (Rental rental : allRentals) {
                if ("ACTIVE".equals(rental.getStatus())) {
                    activeRentals.add(rental);
                }
            }
            
            return activeRentals;
        }
        
        // Normal database access
        List<Rental> activeRentals = new ArrayList<>();
        String sql = "SELECT r.*, " +
                    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
                    "CONCAT(ca.year, ' ', ca.make, ' ', ca.model) AS car_details " +
                    "FROM rentals r " +
                    "JOIN customers c ON r.customer_id = c.customer_id " +
                    "JOIN cars ca ON r.car_id = ca.car_id " +
                    "WHERE r.status = 'ACTIVE' " +
                    "ORDER BY r.start_date";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                activeRentals.add(extractRentalFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting active rentals: " + e.getMessage());
            e.printStackTrace();
        }
        
        return activeRentals;
    }
    
    /**
     * Get rentals for a specific customer
     * @param customerId The ID of the customer
     * @return A list of rentals for the customer
     */
    public List<Rental> getRentalsByCustomerId(int customerId) {
        List<Rental> customerRentals = new ArrayList<>();
        String sql = "SELECT r.*, " +
                    "CONCAT(c.first_name, ' ', c.last_name) AS customer_name, " +
                    "CONCAT(ca.year, ' ', ca.make, ' ', ca.model) AS car_details " +
                    "FROM rentals r " +
                    "JOIN customers c ON r.customer_id = c.customer_id " +
                    "JOIN cars ca ON r.car_id = ca.car_id " +
                    "WHERE r.customer_id = ? " +
                    "ORDER BY r.created_at DESC";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, customerId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    customerRentals.add(extractRentalFromResultSet(rs));
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting rentals by customer ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return customerRentals;
    }
    
    /**
     * Helper method to update car status
     */
    private void updateCarStatus(int carId, String status) {
        String sql = "UPDATE cars SET status = ? WHERE car_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status);
            pstmt.setInt(2, carId);
            
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error updating car status: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Helper method to extract a Rental object from a ResultSet
     */
    private Rental extractRentalFromResultSet(ResultSet rs) throws SQLException {
        Rental rental = new Rental();
        rental.setRentalId(rs.getInt("rental_id"));
        rental.setCustomerId(rs.getInt("customer_id"));
        rental.setCarId(rs.getInt("car_id"));
        
        Timestamp startDate = rs.getTimestamp("start_date");
        if (startDate != null) {
            rental.setStartDate(startDate.toLocalDateTime());
        }
        
        Timestamp endDate = rs.getTimestamp("end_date");
        if (endDate != null) {
            rental.setEndDate(endDate.toLocalDateTime());
        }
        
        rental.setTotalCost(rs.getBigDecimal("total_cost"));
        rental.setStatus(rs.getString("status"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            rental.setCreatedAt(createdAt.toLocalDateTime());
        }
        
        // Additional fields for UI display
        rental.setCustomerName(rs.getString("customer_name"));
        rental.setCarDetails(rs.getString("car_details"));
        
        return rental;
    }
}