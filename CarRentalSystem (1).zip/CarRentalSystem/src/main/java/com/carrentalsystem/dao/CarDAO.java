package com.carrentalsystem.dao;

import com.carrentalsystem.model.Car;
import com.carrentalsystem.util.DatabaseConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Car entity
 */
public class CarDAO {
    
    /**
     * Add a new car to the database
     * @param car The car object to add
     * @return The ID of the newly added car, or -1 if operation failed
     */
    public int addCar(Car car) {
        String sql = "INSERT INTO cars (make, model, year, registration_number, color, " +
                    "daily_rate, status, category, mileage, image_path) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, car.getMake());
            pstmt.setString(2, car.getModel());
            pstmt.setInt(3, car.getYear());
            pstmt.setString(4, car.getRegistrationNumber());
            pstmt.setString(5, car.getColor());
            pstmt.setBigDecimal(6, car.getDailyRate());
            pstmt.setString(7, car.getStatus());
            pstmt.setString(8, car.getCategory());
            pstmt.setInt(9, car.getMileage());
            pstmt.setString(10, car.getImagePath());
            
            int affectedRows = pstmt.executeUpdate();
            
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error adding car: " + e.getMessage());
            e.printStackTrace();
        }
        
        return -1;
    }
    
    /**
     * Update an existing car in the database
     * @param car The car object with updated information
     * @return true if the update was successful, false otherwise
     */
    public boolean updateCar(Car car) {
        String sql = "UPDATE cars SET make = ?, model = ?, year = ?, registration_number = ?, " +
                    "color = ?, daily_rate = ?, status = ?, category = ?, mileage = ?, " +
                    "image_path = ? WHERE car_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, car.getMake());
            pstmt.setString(2, car.getModel());
            pstmt.setInt(3, car.getYear());
            pstmt.setString(4, car.getRegistrationNumber());
            pstmt.setString(5, car.getColor());
            pstmt.setBigDecimal(6, car.getDailyRate());
            pstmt.setString(7, car.getStatus());
            pstmt.setString(8, car.getCategory());
            pstmt.setInt(9, car.getMileage());
            pstmt.setString(10, car.getImagePath());
            pstmt.setInt(11, car.getCarId());
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating car: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Delete a car from the database
     * @param carId The ID of the car to delete
     * @return true if the deletion was successful, false otherwise
     */
    public boolean deleteCar(int carId) {
        String sql = "DELETE FROM cars WHERE car_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, carId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting car: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Get a car by its ID
     * @param carId The ID of the car to retrieve
     * @return The car object if found, null otherwise
     */
    public Car getCarById(int carId) {
        // Check if we're in mock mode
        if (com.carrentalsystem.util.DatabaseConnection.isMockMode()) {
            // Find the car in our mock data
            List<Car> allCars = getAllCars();
            
            for (Car car : allCars) {
                if (car.getCarId() == carId) {
                    return car;
                }
            }
            
            return null;
        }
        
        // Normal database access
        String sql = "SELECT * FROM cars WHERE car_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, carId);
            
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return extractCarFromResultSet(rs);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting car by ID: " + e.getMessage());
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Get all cars from the database
     * @return A list of all cars
     */
    public List<Car> getAllCars() {
        List<Car> cars = new ArrayList<>();
        
        // Check if we're in mock mode
        if (DatabaseConnection.isMockMode()) {
            // Return mock data
            System.out.println("MOCK MODE: Returning sample car data");
            
            // Add some sample cars
            cars.add(new Car(1, "Toyota", "Corolla", 2022, "ABC123", "White", 
                    new BigDecimal("45.00"), "AVAILABLE", "COMPACT", 15000, null));
            cars.add(new Car(2, "Honda", "Civic", 2021, "XYZ456", "Black", 
                    new BigDecimal("50.00"), "AVAILABLE", "COMPACT", 20000, null));
            cars.add(new Car(3, "Ford", "Explorer", 2023, "DEF789", "Blue", 
                    new BigDecimal("75.00"), "AVAILABLE", "SUV", 10000, null));
            cars.add(new Car(4, "BMW", "3 Series", 2022, "GHI101", "Silver", 
                    new BigDecimal("95.00"), "AVAILABLE", "LUXURY", 12000, null));
            cars.add(new Car(5, "Chevrolet", "Malibu", 2021, "JKL112", "Red", 
                    new BigDecimal("55.00"), "AVAILABLE", "MID_SIZE", 18000, null));
                    
            return cars;
        }
        
        // Normal database access
        String sql = "SELECT * FROM cars";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                cars.add(extractCarFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting all cars: " + e.getMessage());
            e.printStackTrace();
        }
        
        return cars;
    }
    
    /**
     * Get all available cars (cars with status 'AVAILABLE')
     * @return A list of available cars
     */
    public List<Car> getAvailableCars() {
        // Check if we're in mock mode
        if (DatabaseConnection.isMockMode()) {
            // Return mock data - filter the getAllCars result for AVAILABLE cars
            List<Car> allCars = getAllCars();
            List<Car> availableCars = new ArrayList<>();
            
            for (Car car : allCars) {
                if ("AVAILABLE".equals(car.getStatus())) {
                    availableCars.add(car);
                }
            }
            
            return availableCars;
        }
        
        // Normal database access
        List<Car> availableCars = new ArrayList<>();
        String sql = "SELECT * FROM cars WHERE status = 'AVAILABLE'";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                availableCars.add(extractCarFromResultSet(rs));
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting available cars: " + e.getMessage());
            e.printStackTrace();
        }
        
        return availableCars;
    }
    
    /**
     * Update the status of a car
     * @param carId The ID of the car to update
     * @param status The new status
     * @return true if the update was successful, false otherwise
     */
    public boolean updateCarStatus(int carId, String status) {
        String sql = "UPDATE cars SET status = ? WHERE car_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, status);
            pstmt.setInt(2, carId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating car status: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Helper method to extract a Car object from a ResultSet
     */
    private Car extractCarFromResultSet(ResultSet rs) throws SQLException {
        Car car = new Car();
        car.setCarId(rs.getInt("car_id"));
        car.setMake(rs.getString("make"));
        car.setModel(rs.getString("model"));
        car.setYear(rs.getInt("year"));
        car.setRegistrationNumber(rs.getString("registration_number"));
        car.setColor(rs.getString("color"));
        car.setDailyRate(rs.getBigDecimal("daily_rate"));
        car.setStatus(rs.getString("status"));
        car.setCategory(rs.getString("category"));
        car.setMileage(rs.getInt("mileage"));
        car.setImagePath(rs.getString("image_path"));
        return car;
    }
}