package com.carrentalsystem.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class for managing database connections
 * 
 * TEMPORARY MOCK VERSION - For demonstration purposes only
 */
public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/car_rental_system";
    private static final String USER = "root";
    private static final String PASSWORD = ""; // Set your MySQL password here
    
    private static Connection connection = null;
    private static boolean mockMode = true; // Set to true to use mock mode
    
    /**
     * Get a connection to the database
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        if (mockMode) {
            // In mock mode, we return null but don't throw an exception
            System.out.println("MOCK MODE: Simulating database connection");
            return null;
        }
        
        if (connection == null || connection.isClosed()) {
            try {
                // Load the JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                
                // Create a connection to the database
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Database connection established successfully");
            } catch (ClassNotFoundException e) {
                System.err.println("MySQL JDBC Driver not found");
                e.printStackTrace();
                throw new SQLException("MySQL JDBC Driver not found", e);
            } catch (SQLException e) {
                System.err.println("Failed to connect to the database");
                e.printStackTrace();
                throw e;
            }
        }
        return connection;
    }
    
    /**
     * Close the database connection
     */
    public static void closeConnection() {
        if (mockMode) {
            System.out.println("MOCK MODE: Simulating database connection close");
            return;
        }
        
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed");
            } catch (SQLException e) {
                System.err.println("Error closing database connection");
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Check if we're running in mock mode
     * @return true if in mock mode, false otherwise
     */
    public static boolean isMockMode() {
        return mockMode;
    }
}