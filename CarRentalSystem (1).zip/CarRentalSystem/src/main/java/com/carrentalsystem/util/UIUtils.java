package com.carrentalsystem.util;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/**
 * Utility class for UI-related operations
 */
public class UIUtils {
    
    // Color scheme
    public static final Color PRIMARY_COLOR = new Color(0, 123, 255);
    public static final Color SECONDARY_COLOR = new Color(108, 117, 125);
    public static final Color SUCCESS_COLOR = new Color(40, 167, 69);
    public static final Color DANGER_COLOR = new Color(220, 53, 69);
    public static final Color WARNING_COLOR = new Color(255, 193, 7);
    public static final Color INFO_COLOR = new Color(23, 162, 184);
    public static final Color LIGHT_COLOR = new Color(248, 249, 250);
    public static final Color DARK_COLOR = new Color(52, 58, 64);
    
    // Font sizes
    public static final int FONT_SIZE_SMALL = 12;
    public static final int FONT_SIZE_MEDIUM = 14;
    public static final int FONT_SIZE_LARGE = 16;
    public static final int FONT_SIZE_XLARGE = 20;
    
    // Fonts
    public static final Font FONT_REGULAR = new Font("Segoe UI", Font.PLAIN, FONT_SIZE_MEDIUM);
    public static final Font FONT_BOLD = new Font("Segoe UI", Font.BOLD, FONT_SIZE_MEDIUM);
    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, FONT_SIZE_XLARGE);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.BOLD, FONT_SIZE_LARGE);
    
    // Padding and margins
    public static final int PADDING_SMALL = 5;
    public static final int PADDING_MEDIUM = 10;
    public static final int PADDING_LARGE = 15;
    public static final int PADDING_XLARGE = 20;
    
    // Date and time formatters
    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    
    // Currency formatter
    public static final NumberFormat CURRENCY_FORMATTER = NumberFormat.getCurrencyInstance(Locale.US);
    
    /**
     * Create a styled button with the specified text and color
     * @param text The button text
     * @param color The button color
     * @return A styled JButton
     */
    public static JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(FONT_BOLD);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    
    /**
     * Create a styled panel with the specified layout
     * @param layout The layout manager
     * @return A styled JPanel
     */
    public static JPanel createPanel(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setBackground(LIGHT_COLOR);
        panel.setBorder(new EmptyBorder(PADDING_MEDIUM, PADDING_MEDIUM, PADDING_MEDIUM, PADDING_MEDIUM));
        return panel;
    }
    
    /**
     * Create a styled label with the specified text
     * @param text The label text
     * @param font The font to use
     * @return A styled JLabel
     */
    public static JLabel createLabel(String text, Font font) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(DARK_COLOR);
        return label;
    }
    
    /**
     * Create a styled text field
     * @param columns The number of columns
     * @return A styled JTextField
     */
    public static JTextField createTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setFont(FONT_REGULAR);
        return textField;
    }
    
    /**
     * Create a styled combo box with the specified items
     * @param items The items to include in the combo box
     * @return A styled JComboBox
     */
    public static <T> JComboBox<T> createComboBox(T[] items) {
        JComboBox<T> comboBox = new JComboBox<>(items);
        comboBox.setFont(FONT_REGULAR);
        return comboBox;
    }
    
    /**
     * Create a styled table
     * @return A styled JTable
     */
    public static JTable createTable() {
        JTable table = new JTable();
        table.setFont(FONT_REGULAR);
        table.setRowHeight(25);
        table.setSelectionBackground(PRIMARY_COLOR);
        table.setSelectionForeground(Color.WHITE);
        table.setShowGrid(true);
        table.setGridColor(LIGHT_COLOR.darker());
        
        // Style the header
        table.getTableHeader().setFont(FONT_BOLD);
        table.getTableHeader().setBackground(SECONDARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        
        return table;
    }
    
    /**
     * Format a LocalDateTime object as a date string
     * @param dateTime The LocalDateTime to format
     * @return A formatted date string
     */
    public static String formatDate(LocalDateTime dateTime) {
        if (dateTime == null) {
            return "";
        }
        return dateTime.format(DATE_FORMATTER);
    }
    
    /**
     * Format a LocalDateTime object as a date and time string
     * @param dateTime The LocalDateTime to format
     * @return A formatted date and time string
     */
    public static String formatDateTime(LocalDateTime dateTime) {
        if (dateTime == null) {
            return "";
        }
        return dateTime.format(DATE_TIME_FORMATTER);
    }
    
    /**
     * Show an error message dialog
     * @param parent The parent component
     * @param message The error message
     */
    public static void showErrorMessage(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    /**
     * Show an information message dialog
     * @param parent The parent component
     * @param message The information message
     */
    public static void showInfoMessage(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Show a confirmation dialog
     * @param parent The parent component
     * @param message The confirmation message
     * @return true if the user confirmed, false otherwise
     */
    public static boolean showConfirmDialog(Component parent, String message) {
        int result = JOptionPane.showConfirmDialog(parent, message, "Confirmation", 
                                                 JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        return result == JOptionPane.YES_OPTION;
    }
}