package com.carrentalsystem.model;

import java.math.BigDecimal;

/**
 * Model class representing a car in the rental system
 */
public class Car {
    private int carId;
    private String make;
    private String model;
    private int year;
    private String registrationNumber;
    private String color;
    private BigDecimal dailyRate;
    private String status; // AVAILABLE, RENTED, MAINTENANCE
    private String category; // ECONOMY, COMPACT, MID_SIZE, FULL_SIZE, SUV, LUXURY
    private int mileage;
    private String imagePath;
    
    // Default constructor
    public Car() {
    }
    
    // Constructor with all fields except carId (for new cars)
    public Car(String make, String model, int year, String registrationNumber, 
               String color, BigDecimal dailyRate, String status, String category, 
               int mileage, String imagePath) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.registrationNumber = registrationNumber;
        this.color = color;
        this.dailyRate = dailyRate;
        this.status = status;
        this.category = category;
        this.mileage = mileage;
        this.imagePath = imagePath;
    }
    
    // Constructor with all fields (for existing cars)
    public Car(int carId, String make, String model, int year, String registrationNumber, 
               String color, BigDecimal dailyRate, String status, String category, 
               int mileage, String imagePath) {
        this.carId = carId;
        this.make = make;
        this.model = model;
        this.year = year;
        this.registrationNumber = registrationNumber;
        this.color = color;
        this.dailyRate = dailyRate;
        this.status = status;
        this.category = category;
        this.mileage = mileage;
        this.imagePath = imagePath;
    }
    
    // Getters and Setters
    public int getCarId() {
        return carId;
    }
    
    public void setCarId(int carId) {
        this.carId = carId;
    }
    
    public String getMake() {
        return make;
    }
    
    public void setMake(String make) {
        this.make = make;
    }
    
    public String getModel() {
        return model;
    }
    
    public void setModel(String model) {
        this.model = model;
    }
    
    public int getYear() {
        return year;
    }
    
    public void setYear(int year) {
        this.year = year;
    }
    
    public String getRegistrationNumber() {
        return registrationNumber;
    }
    
    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public BigDecimal getDailyRate() {
        return dailyRate;
    }
    
    public void setDailyRate(BigDecimal dailyRate) {
        this.dailyRate = dailyRate;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public int getMileage() {
        return mileage;
    }
    
    public void setMileage(int mileage) {
        this.mileage = mileage;
    }
    
    public String getImagePath() {
        return imagePath;
    }
    
    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
    
    @Override
    public String toString() {
        return year + " " + make + " " + model + " (" + registrationNumber + ")";
    }
}