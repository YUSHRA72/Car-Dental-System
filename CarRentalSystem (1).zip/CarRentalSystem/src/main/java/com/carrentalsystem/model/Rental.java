package com.carrentalsystem.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Model class representing a rental transaction in the system
 */
public class Rental {
    private int rentalId;
    private int customerId;
    private int carId;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private BigDecimal totalCost;
    private String status; // ACTIVE, COMPLETED, CANCELLED
    private LocalDateTime createdAt;
    
    // Additional fields for UI display (not stored in database)
    private String customerName;
    private String carDetails;
    
    // Default constructor
    public Rental() {
    }
    
    // Constructor without rentalId and createdAt (for new rentals)
    public Rental(int customerId, int carId, LocalDateTime startDate, 
                 LocalDateTime endDate, BigDecimal totalCost, String status) {
        this.customerId = customerId;
        this.carId = carId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalCost = totalCost;
        this.status = status;
    }
    
    // Constructor with all fields (for existing rentals)
    public Rental(int rentalId, int customerId, int carId, LocalDateTime startDate, 
                 LocalDateTime endDate, BigDecimal totalCost, String status, 
                 LocalDateTime createdAt) {
        this.rentalId = rentalId;
        this.customerId = customerId;
        this.carId = carId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalCost = totalCost;
        this.status = status;
        this.createdAt = createdAt;
    }
    
    // Getters and Setters
    public int getRentalId() {
        return rentalId;
    }
    
    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }
    
    public int getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    public int getCarId() {
        return carId;
    }
    
    public void setCarId(int carId) {
        this.carId = carId;
    }
    
    public LocalDateTime getStartDate() {
        return startDate;
    }
    
    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }
    
    public LocalDateTime getEndDate() {
        return endDate;
    }
    
    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }
    
    public BigDecimal getTotalCost() {
        return totalCost;
    }
    
    public void setTotalCost(BigDecimal totalCost) {
        this.totalCost = totalCost;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getCustomerName() {
        return customerName;
    }
    
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    
    public String getCarDetails() {
        return carDetails;
    }
    
    public void setCarDetails(String carDetails) {
        this.carDetails = carDetails;
    }
    
    @Override
    public String toString() {
        return "Rental #" + rentalId + " - " + status;
    }
}