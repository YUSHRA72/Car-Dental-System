package com.carrentalsystem.model;

import java.time.LocalDateTime;

/**
 * Model class representing a customer in the rental system
 */
public class Customer {
    private int customerId;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String address;
    private String driverLicense;
    private LocalDateTime registrationDate;
    
    // Default constructor
    public Customer() {
    }
    
    // Constructor without customerId and registrationDate (for new customers)
    public Customer(String firstName, String lastName, String email, String phone, 
                   String address, String driverLicense) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.driverLicense = driverLicense;
    }
    
    // Constructor with all fields (for existing customers)
    public Customer(int customerId, String firstName, String lastName, String email, 
                   String phone, String address, String driverLicense, 
                   LocalDateTime registrationDate) {
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.driverLicense = driverLicense;
        this.registrationDate = registrationDate;
    }
    
    // Getters and Setters
    public int getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    
    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPhone() {
        return phone;
    }
    
    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getDriverLicense() {
        return driverLicense;
    }
    
    public void setDriverLicense(String driverLicense) {
        this.driverLicense = driverLicense;
    }
    
    public LocalDateTime getRegistrationDate() {
        return registrationDate;
    }
    
    public void setRegistrationDate(LocalDateTime registrationDate) {
        this.registrationDate = registrationDate;
    }
    
    @Override
    public String toString() {
        return firstName + " " + lastName + " (" + email + ")";
    }
    
    // Helper method to get full name
    public String getFullName() {
        return firstName + " " + lastName;
    }
}