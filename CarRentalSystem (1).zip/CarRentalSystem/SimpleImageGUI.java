import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import javax.imageio.ImageIO;

/**
 * Simple GUI application that demonstrates using images in a Java Swing interface
 */
public class SimpleImageGUI {
    
    private JFrame frame;
    private JFrame dashboardFrame;
    private Image backgroundImage;
    private Image iconImage;
    
    // Exchange rate (1 USD = 83.15 INR as of May 2023)
    private final double USD_TO_INR_RATE = 83.15;
    
    // Data storage
    private String currentUser;
    private java.util.List<Map<String, String>> rentalHistory = new ArrayList<>();
    private java.util.List<Map<String, String>> availableCars = new ArrayList<>();
    private java.util.List<Map<String, String>> activeRentals = new ArrayList<>();
    private Map<String, Map<String, String>> userProfiles = new HashMap<>();
    
    // File paths for data storage
    private final String DATA_DIR = "c:/Users/Asus/OneDrive/Desktop/Java project/CarRentalSystem/data";
    private final String RENTAL_HISTORY_FILE = DATA_DIR + "/rental_history.dat";
    private final String AVAILABLE_CARS_FILE = DATA_DIR + "/available_cars.dat";
    private final String ACTIVE_RENTALS_FILE = DATA_DIR + "/active_rentals.dat";
    private final String USER_PROFILES_FILE = DATA_DIR + "/user_profiles.dat";
    private final String ACTIVITY_LOG_FILE = DATA_DIR + "/activity_log.txt";
    
    /**
     * Constructor
     */
    public SimpleImageGUI() {
        // Create data directory if it doesn't exist
        createDataDirectory();
        
        // Initialize data
        initializeData();
        
        // Load images
        loadImages();
        
        // Create and show GUI
        createAndShowGUI();
    }
    
    /**
     * Create data directory if it doesn't exist
     */
    private void createDataDirectory() {
        File dataDir = new File(DATA_DIR);
        if (!dataDir.exists()) {
            boolean created = dataDir.mkdirs();
            if (created) {
                System.out.println("Created data directory: " + DATA_DIR);
            } else {
                System.out.println("Failed to create data directory: " + DATA_DIR);
            }
        }
    }
    
    /**
     * Initialize data from files or with default values
     */
    private void initializeData() {
        // Load available cars
        if (!loadAvailableCars()) {
            // Initialize with default data
            initializeDefaultCars();
        }
        
        // Load rental history
        if (!loadRentalHistory()) {
            // Initialize with empty list
            rentalHistory = new ArrayList<>();
        }
        
        // Load active rentals
        if (!loadActiveRentals()) {
            // Initialize with empty list
            activeRentals = new ArrayList<>();
        }
        
        // Load user profiles
        if (!loadUserProfiles()) {
            // Initialize with default user
            initializeDefaultUser();
        }
        
        // Log application start
        logActivity("Application started");
    }
    
    /**
     * Load images from files
     */
    private void loadImages() {
        try {
            // Try to load background image from file
            File backgroundFile = new File("c:/Users/Asus/OneDrive/Desktop/Java project/CarRentalSystem/images/background.jpg");
            System.out.println("Background file exists: " + backgroundFile.exists());
            if (backgroundFile.exists()) {
                backgroundImage = ImageIO.read(backgroundFile);
                System.out.println("Background image loaded: " + (backgroundImage != null));
            }
            
            // Try to load icon image from file
            File iconFile = new File("c:/Users/Asus/OneDrive/Desktop/Java project/CarRentalSystem/images/icon.jpg");
            System.out.println("Icon file exists: " + iconFile.exists());
            if (iconFile.exists()) {
                iconImage = ImageIO.read(iconFile);
                System.out.println("Icon image loaded: " + (iconImage != null));
            }
            
            // If images couldn't be loaded, create placeholder images
            if (backgroundImage == null) {
                System.out.println("Creating placeholder background image");
                backgroundImage = createGradientImage(800, 600, new Color(70, 130, 180), new Color(25, 25, 112));
            }
            
            if (iconImage == null) {
                System.out.println("Creating placeholder icon image");
                iconImage = createIconImage(32, 32);
            }
        } catch (IOException e) {
            System.out.println("Error loading images: " + e.getMessage());
            e.printStackTrace();
            
            // Create placeholder images if an exception occurred
            backgroundImage = createGradientImage(800, 600, new Color(70, 130, 180), new Color(25, 25, 112));
            iconImage = createIconImage(32, 32);
        }
    }
    
    /**
     * Create a gradient image to use as a placeholder
     */
    private Image createGradientImage(int width, int height, Color startColor, Color endColor) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        
        // Create a gradient paint
        GradientPaint gp = new GradientPaint(
            0, 0, startColor,
            0, height, endColor
        );
        
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, width, height);
        
        // Add some visual interest
        g2d.setColor(new Color(255, 255, 255, 50));
        for (int i = 0; i < width; i += 20) {
            g2d.drawLine(i, 0, i, height);
        }
        for (int i = 0; i < height; i += 20) {
            g2d.drawLine(0, i, width, i);
        }
        
        g2d.dispose();
        return image;
    }
    
    /**
     * Create a simple icon image to use as a placeholder
     */
    private Image createIconImage(int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = image.createGraphics();
        
        // Enable anti-aliasing
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Draw a car icon
        g2d.setColor(new Color(0, 123, 255));
        g2d.fillRoundRect(2, 8, width - 4, height/2 - 2, 5, 5);
        
        // Draw wheels
        g2d.setColor(Color.BLACK);
        g2d.fillOval(5, height/2 + 2, 6, 6);
        g2d.fillOval(width - 11, height/2 + 2, 6, 6);
        
        g2d.dispose();
        return image;
    }
    
    /**
     * Create and display the GUI
     */
    private void createAndShowGUI() {
        // Create the main frame
        frame = new JFrame("Image GUI Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        
        // Set icon if available
        if (iconImage != null) {
            frame.setIconImage(iconImage);
        }
        
        // Create main panel with background image
        JPanel mainPanel;
        if (backgroundImage != null) {
            mainPanel = new BackgroundPanel(backgroundImage);
        } else {
            mainPanel = new JPanel();
            mainPanel.setBackground(new Color(100, 149, 237)); // Cornflower blue as fallback
        }
        mainPanel.setLayout(new BorderLayout());
        
        // Create a login panel
        JPanel loginPanel = createLoginPanel();
        
        // Add components to main panel
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        mainPanel.add(loginPanel, BorderLayout.CENTER);
        mainPanel.add(createFooterPanel(), BorderLayout.SOUTH);
        
        // Set the content pane
        frame.setContentPane(mainPanel);
        
        // Display the frame
        frame.setVisible(true);
    }
    
    /**
     * Create the header panel
     */
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 0, 0, 150));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        
        // Create title with icon
        JLabel titleLabel = new JLabel("Car Rental System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        
        // Add icon to title if available
        if (iconImage != null) {
            Image scaledIcon = iconImage.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            titleLabel.setIcon(new ImageIcon(scaledIcon));
            titleLabel.setIconTextGap(15);
        }
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        return headerPanel;
    }
    
    /**
     * Create the login panel
     */
    private JPanel createLoginPanel() {
        // Create a semi-transparent panel
        JPanel loginPanel = new JPanel();
        loginPanel.setLayout(new GridBagLayout());
        loginPanel.setBackground(new Color(0, 0, 0, 100));
        
        // Create a form panel with glass effect
        JPanel formPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create glass effect with gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 200),
                    0, getHeight(), new Color(220, 220, 255, 200)
                );
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                
                // Add a subtle border
                g2d.setColor(new Color(255, 255, 255, 100));
                g2d.setStroke(new BasicStroke(2f));
                g2d.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 20, 20);
                
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Title
        JLabel titleLabel = new JLabel("Login to Your Account", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);
        
        // Username
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(usernameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JTextField usernameField = createStyledTextField(15);
        formPanel.add(usernameField, gbc);
        
        // Password
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(passwordLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JPasswordField passwordField = createStyledPasswordField(15);
        formPanel.add(passwordField, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        
        JButton loginButton = createStyledButton("Login", new Color(0, 123, 255));
        
        // Add icon to button if available
        if (iconImage != null) {
            Image scaledIcon = iconImage.getScaledInstance(16, 16, Image.SCALE_SMOOTH);
            loginButton.setIcon(new ImageIcon(scaledIcon));
        }
        
        JButton cancelButton = createStyledButton("Cancel", new Color(220, 53, 69));
        
        // Add action listeners
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, 
                        "Please enter both username and password.", 
                        "Login Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Check if user exists
                if (userProfiles.containsKey(username)) {
                    Map<String, String> userProfile = userProfiles.get(username);
                    
                    // Check password
                    if (userProfile.get("password").equals(password)) {
                        // Set current user
                        currentUser = username;
                        
                        // Log login activity
                        logActivity("Logged in");
                        
                        // Close login screen
                        frame.dispose();
                        
                        // Show dashboard screen
                        showDashboard(username);
                    } else {
                        JOptionPane.showMessageDialog(frame, 
                            "Invalid password. Please try again.", 
                            "Login Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    // Ask if user wants to create a new account
                    int result = JOptionPane.showConfirmDialog(frame, 
                        "User '" + username + "' does not exist. Would you like to create a new account?", 
                        "Create Account", JOptionPane.YES_NO_OPTION);
                    
                    if (result == JOptionPane.YES_OPTION) {
                        // Create new user profile
                        Map<String, String> newUser = new HashMap<>();
                        newUser.put("fullName", username);
                        newUser.put("email", "");
                        newUser.put("phone", "");
                        newUser.put("address", "");
                        newUser.put("password", password);
                        
                        userProfiles.put(username, newUser);
                        saveUserProfiles();
                        
                        // Set current user
                        currentUser = username;
                        
                        // Log account creation
                        logActivity("Created new account");
                        
                        // Close login screen
                        frame.dispose();
                        
                        // Show dashboard screen
                        showDashboard(username);
                    }
                }
            }
        });
        
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);
        formPanel.add(buttonPanel, gbc);
        
        // Add form panel to login panel
        loginPanel.add(formPanel);
        
        return loginPanel;
    }
    
    /**
     * Create the footer panel
     */
    private JPanel createFooterPanel() {
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footerPanel.setBackground(new Color(0, 0, 0, 150));
        footerPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        
        JLabel copyrightLabel = new JLabel("© 2025 Car Rental System. All rights reserved.");
        copyrightLabel.setForeground(Color.WHITE);
        footerPanel.add(copyrightLabel);
        
        return footerPanel;
    }
    
    /**
     * Create a styled text field
     */
    private JTextField createStyledTextField(int columns) {
        JTextField textField = new JTextField(columns);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        textField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 123, 255), 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        textField.setBackground(new Color(240, 248, 255));
        return textField;
    }
    
    /**
     * Create a styled password field
     */
    private JPasswordField createStyledPasswordField(int columns) {
        JPasswordField passwordField = new JPasswordField(columns);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0, 123, 255), 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        passwordField.setBackground(new Color(240, 248, 255));
        return passwordField;
    }
    
    /**
     * Create a styled button with gradient and hover effects
     */
    private JButton createStyledButton(String text, Color baseColor) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Get button state
                boolean isPressed = getModel().isPressed();
                boolean isRollover = getModel().isRollover();
                
                // Choose colors based on state
                Color startColor, endColor;
                if (isPressed) {
                    startColor = baseColor.darker();
                    endColor = baseColor;
                } else if (isRollover) {
                    startColor = baseColor.brighter();
                    endColor = baseColor;
                } else {
                    startColor = baseColor;
                    endColor = baseColor.darker();
                }
                
                // Create gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, startColor,
                    0, getHeight(), endColor
                );
                g2d.setPaint(gp);
                
                // Draw rounded button
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                
                // Add highlight
                if (!isPressed) {
                    g2d.setColor(new Color(255, 255, 255, 100));
                    g2d.drawLine(0, 0, getWidth(), 0);
                    g2d.drawLine(0, 0, 0, getHeight());
                }
                
                g2d.dispose();
                
                // Let UI delegate paint the text and icon
                super.paintComponent(g);
            }
        };
        
        // Configure button
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        
        return button;
    }
    
    /**
     * Background panel class for displaying a background image
     */
    private class BackgroundPanel extends JPanel {
        private Image backgroundImage;
        
        public BackgroundPanel(Image backgroundImage) {
            this.backgroundImage = backgroundImage;
            setOpaque(false);
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                Graphics2D g2d = (Graphics2D) g.create();
                
                // Enable better quality rendering
                g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                
                // Draw the background image
                g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                
                // Add a subtle overlay gradient
                GradientPaint overlay = new GradientPaint(
                    0, 0, new Color(0, 0, 0, 50),
                    0, getHeight(), new Color(0, 0, 0, 150)
                );
                g2d.setPaint(overlay);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                g2d.dispose();
            }
        }
    }
    
    /**
     * Show the dashboard screen after successful login
     */
    private void showDashboard(String username) {
        // Log dashboard access
        logActivity("Accessed dashboard");
        
        // Create a new frame for the dashboard
        dashboardFrame = new JFrame("Car Rental System - Dashboard");
        dashboardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        dashboardFrame.setSize(1000, 700);
        dashboardFrame.setLocationRelativeTo(null);
        
        // Set icon if available
        if (iconImage != null) {
            dashboardFrame.setIconImage(iconImage);
        }
        
        // Create main panel with background image
        JPanel mainPanel;
        if (backgroundImage != null) {
            mainPanel = new BackgroundPanel(backgroundImage);
        } else {
            mainPanel = new JPanel();
            mainPanel.setBackground(new Color(100, 149, 237)); // Cornflower blue as fallback
        }
        mainPanel.setLayout(new BorderLayout());
        
        // Add components to main panel
        mainPanel.add(createDashboardHeader(username), BorderLayout.NORTH);
        mainPanel.add(createDashboardContent(), BorderLayout.CENTER);
        mainPanel.add(createFooterPanel(), BorderLayout.SOUTH);
        
        // Set the content pane
        dashboardFrame.setContentPane(mainPanel);
        
        // Display the frame
        dashboardFrame.setVisible(true);
    }
    
    /**
     * Create the dashboard header panel
     */
    private JPanel createDashboardHeader(String username) {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(0, 0, 0, 150));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        // Create title with icon
        JLabel titleLabel = new JLabel("Car Rental System");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        
        // Add icon to title if available
        if (iconImage != null) {
            Image scaledIcon = iconImage.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            titleLabel.setIcon(new ImageIcon(scaledIcon));
            titleLabel.setIconTextGap(15);
        }
        
        // Create user info panel
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        userPanel.setOpaque(false);
        
        JLabel welcomeLabel = new JLabel("Welcome, " + username + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 14));
        welcomeLabel.setForeground(Color.WHITE);
        
        JButton logoutButton = createStyledButton("Logout", new Color(220, 53, 69));
        logoutButton.setFont(new Font("Arial", Font.BOLD, 12));
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Show confirmation dialog
                int result = JOptionPane.showConfirmDialog(
                    dashboardFrame,
                    "Are you sure you want to logout?",
                    "Confirm Logout",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
                );
                
                if (result == JOptionPane.YES_OPTION) {
                    // Save all data
                    saveAllData();
                    
                    // Log logout activity
                    logActivity("Logged out");
                    
                    // Reset current user
                    currentUser = null;
                    
                    // Close dashboard
                    dashboardFrame.dispose();
                    
                    // Create new login screen
                    new SimpleImageGUI();
                }
            }
        });
        
        userPanel.add(welcomeLabel);
        userPanel.add(logoutButton);
        
        headerPanel.add(titleLabel, BorderLayout.WEST);
        headerPanel.add(userPanel, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    /**
     * Create the dashboard content panel
     */
    private JPanel createDashboardContent() {
        // Create a panel with a semi-transparent overlay
        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Create a tabbed pane for different sections
        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 14));
        tabbedPane.setBackground(new Color(255, 255, 255, 200));
        tabbedPane.setOpaque(false);
        
        // Add tabs with content
        tabbedPane.addTab("Dashboard", createDashboardTab());
        tabbedPane.addTab("Available Cars", createAvailableCarsTab());
        tabbedPane.addTab("My Rentals", createMyRentalsTab());
        tabbedPane.addTab("Profile", createProfileTab());
        
        // Add icons to tabs if available
        if (iconImage != null) {
            Image scaledIcon = iconImage.getScaledInstance(16, 16, Image.SCALE_SMOOTH);
            ImageIcon tabIcon = new ImageIcon(scaledIcon);
            
            for (int i = 0; i < tabbedPane.getTabCount(); i++) {
                tabbedPane.setIconAt(i, tabIcon);
            }
        }
        
        contentPanel.add(tabbedPane, BorderLayout.CENTER);
        
        return contentPanel;
    }
    
    /**
     * Create the dashboard overview tab
     */
    private JPanel createDashboardTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Welcome message
        JPanel welcomePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        welcomePanel.setOpaque(false);
        
        JLabel welcomeLabel = new JLabel("Welcome to the Car Rental System Dashboard!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomePanel.add(welcomeLabel);
        
        // Dashboard cards
        JPanel cardsPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        cardsPanel.setOpaque(false);
        cardsPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        cardsPanel.add(createDashboardCard("Available Cars", "24", new Color(0, 123, 255)));
        cardsPanel.add(createDashboardCard("Active Rentals", "3", new Color(40, 167, 69)));
        cardsPanel.add(createDashboardCard("Completed Rentals", "12", new Color(255, 193, 7)));
        cardsPanel.add(createDashboardCard("Total Spent", "$1,240 / " + convertToRupees("$1,240"), new Color(220, 53, 69)));
        
        panel.add(welcomePanel, BorderLayout.NORTH);
        panel.add(cardsPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    /**
     * Create a dashboard card
     */
    private JPanel createDashboardCard(String title, String value, Color color) {
        JPanel cardPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create glass effect with gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 220),
                    0, getHeight(), new Color(240, 240, 255, 220)
                );
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 15, 15);
                
                // Add a border
                g2d.setColor(color);
                g2d.setStroke(new BasicStroke(2f));
                g2d.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 15, 15);
                
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        cardPanel.setOpaque(false);
        cardPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Title
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        titleLabel.setForeground(color);
        
        // Add icon to title if available
        if (iconImage != null) {
            Image scaledIcon = iconImage.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            titleLabel.setIcon(new ImageIcon(scaledIcon));
            titleLabel.setIconTextGap(10);
        }
        
        // Value
        JLabel valueLabel = new JLabel(value, JLabel.CENTER);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 36));
        valueLabel.setForeground(color);
        
        cardPanel.add(titleLabel, BorderLayout.NORTH);
        cardPanel.add(valueLabel, BorderLayout.CENTER);
        
        return cardPanel;
    }
    
    /**
     * Create the available cars tab
     */
    private JPanel createAvailableCarsTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Create a table model
        String[] columns = {"Car ID", "Make", "Model", "Year", "Color", "Daily Rate (USD)", "Daily Rate (INR)", "Status"};
        Object[][] data = {
            {"C001", "Toyota", "Camry", "2023", "Silver", "$45/day", convertToRupees("$45/day"), "Available"},
            {"C002", "Honda", "Accord", "2022", "Black", "$42/day", convertToRupees("$42/day"), "Available"},
            {"C003", "Ford", "Mustang", "2023", "Red", "$65/day", convertToRupees("$65/day"), "Available"},
            {"C004", "Chevrolet", "Malibu", "2022", "Blue", "$40/day", convertToRupees("$40/day"), "Available"},
            {"C005", "Nissan", "Altima", "2023", "White", "$43/day", convertToRupees("$43/day"), "Available"},
            {"C006", "BMW", "3 Series", "2022", "Black", "$75/day", convertToRupees("$75/day"), "Available"},
            {"C007", "Mercedes", "C-Class", "2023", "Silver", "$78/day", convertToRupees("$78/day"), "Available"},
            {"C008", "Audi", "A4", "2022", "Gray", "$72/day", convertToRupees("$72/day"), "Available"}
        };
        
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setGridColor(new Color(200, 200, 200));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        
        // Add a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Add a search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        searchPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JLabel searchLabel = new JLabel("Search:");
        searchLabel.setFont(new Font("Arial", Font.BOLD, 14));
        
        JTextField searchField = createStyledTextField(20);
        
        JButton searchButton = createStyledButton("Search", new Color(0, 123, 255));
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchTerm = searchField.getText().trim().toLowerCase();
                if (searchTerm.isEmpty()) {
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "Please enter a search term.", 
                        "Search", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
                // Simple search functionality
                boolean found = false;
                for (int i = 0; i < table.getRowCount(); i++) {
                    for (int j = 0; j < table.getColumnCount(); j++) {
                        String cellValue = table.getValueAt(i, j).toString().toLowerCase();
                        if (cellValue.contains(searchTerm)) {
                            // Select the row where match is found
                            table.setRowSelectionInterval(i, i);
                            table.scrollRectToVisible(table.getCellRect(i, 0, true));
                            found = true;
                            break;
                        }
                    }
                    if (found) break;
                }
                
                if (!found) {
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "No matches found for '" + searchTerm + "'.", 
                        "Search Results", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        JButton rentButton = createStyledButton("Rent Selected Car", new Color(40, 167, 69));
        rentButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "Please select a car to rent.", 
                        "Rent Car", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
                String carId = table.getValueAt(selectedRow, 0).toString();
                String carMake = table.getValueAt(selectedRow, 1).toString();
                String carModel = table.getValueAt(selectedRow, 2).toString();
                String dailyRate = table.getValueAt(selectedRow, 5).toString();
                
                // Show rental dialog
                showRentCarDialog(carId, carMake + " " + carModel, dailyRate);
            }
        });
        
        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(rentButton);
        
        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    /**
     * Create the my rentals tab
     */
    private JPanel createMyRentalsTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Create a table model
        String[] columns = {"Rental ID", "Car", "Start Date", "End Date", "Total Cost (USD)", "Total Cost (INR)", "Status"};
        
        // Get user's rentals
        java.util.List<Map<String, String>> userRentals = new ArrayList<>();
        for (Map<String, String> rental : activeRentals) {
            if (rental.get("user").equals(currentUser)) {
                userRentals.add(rental);
            }
        }
        
        // Create data array
        Object[][] data;
        if (userRentals.isEmpty()) {
            // Default data if no rentals
            data = new Object[1][7];
            data[0] = new Object[]{"", "No active rentals", "", "", "", "", ""};
        } else {
            data = new Object[userRentals.size()][7];
            for (int i = 0; i < userRentals.size(); i++) {
                Map<String, String> rental = userRentals.get(i);
                data[i] = new Object[]{
                    rental.get("rentalId"),
                    rental.get("carName"),
                    rental.get("startDate"),
                    rental.get("endDate"),
                    rental.get("totalCost"),
                    rental.get("totalCostInr"),
                    rental.get("status")
                };
            }
        }
        
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setGridColor(new Color(200, 200, 200));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        
        // Add a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Add a button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        JButton returnButton = createStyledButton("Return Selected Car", new Color(220, 53, 69));
        returnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "Please select a rental to return.", 
                        "Return Car", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
                String rentalId = table.getValueAt(selectedRow, 0).toString();
                String carName = table.getValueAt(selectedRow, 1).toString();
                String status = table.getValueAt(selectedRow, 5).toString();
                
                if (!status.equals("Active")) {
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "Only active rentals can be returned.", 
                        "Return Car", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                // Show confirmation dialog
                int result = JOptionPane.showConfirmDialog(
                    dashboardFrame,
                    "Are you sure you want to return " + carName + "?",
                    "Confirm Return",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
                );
                
                if (result == JOptionPane.YES_OPTION) {
                    // Update the table
                    table.setValueAt("Completed", selectedRow, 6);
                    
                    // Update rental status in data
                    for (Map<String, String> rental : activeRentals) {
                        if (rental.get("rentalId").equals(rentalId)) {
                            rental.put("status", "Completed");
                            rental.put("returnDate", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                            break;
                        }
                    }
                    
                    // Update rental history
                    for (Map<String, String> rental : rentalHistory) {
                        if (rental.get("rentalId").equals(rentalId)) {
                            rental.put("status", "Completed");
                            rental.put("returnDate", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                            break;
                        }
                    }
                    
                    // Remove from active rentals
                    activeRentals.removeIf(rental -> rental.get("rentalId").equals(rentalId));
                    
                    // Save data
                    saveActiveRentals();
                    saveRentalHistory();
                    
                    // Log activity
                    logActivity("Returned car: " + carName + " (Rental ID: " + rentalId + ")");
                    
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "Car successfully returned!\n\n" +
                        "Rental ID: " + rentalId + "\n" +
                        "Car: " + carName + "\n" +
                        "Status: Completed", 
                        "Return Successful", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
        
        JButton historyButton = createStyledButton("View Rental History", new Color(108, 117, 125));
        historyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showRentalHistoryDialog();
            }
        });
        
        buttonPanel.add(returnButton);
        buttonPanel.add(historyButton);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Create the profile tab
     */
    private JPanel createProfileTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Create a form panel
        JPanel formPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create glass effect with gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 200),
                    0, getHeight(), new Color(240, 240, 255, 200)
                );
                g2d.setPaint(gp);
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                
                // Add a subtle border
                g2d.setColor(new Color(0, 123, 255, 100));
                g2d.setStroke(new BasicStroke(2f));
                g2d.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 20, 20);
                
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        formPanel.setOpaque(false);
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(8, 8, 8, 8);
        
        // Title
        JLabel titleLabel = new JLabel("User Profile", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);
        
        // Add profile picture
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        
        JPanel picturePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        picturePanel.setOpaque(false);
        
        JLabel pictureLabel;
        if (iconImage != null) {
            Image scaledIcon = iconImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
            pictureLabel = new JLabel(new ImageIcon(scaledIcon));
        } else {
            pictureLabel = new JLabel("No Image");
            pictureLabel.setFont(new Font("Arial", Font.BOLD, 14));
        }
        pictureLabel.setBorder(BorderFactory.createLineBorder(new Color(0, 123, 255), 2));
        picturePanel.add(pictureLabel);
        formPanel.add(picturePanel, gbc);
        
        // Name
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 1;
        JLabel nameLabel = new JLabel("Full Name:");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(nameLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JTextField nameField = createStyledTextField(20);
        formPanel.add(nameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(emailLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField emailField = createStyledTextField(20);
        formPanel.add(emailField, gbc);
        
        // Phone
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(phoneLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField phoneField = createStyledTextField(20);
        formPanel.add(phoneField, gbc);
        
        // Address
        gbc.gridx = 0;
        gbc.gridy = 5;
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(addressLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        JTextField addressField = createStyledTextField(20);
        formPanel.add(addressField, gbc);
        
        // Load user profile data if available
        if (userProfiles.containsKey(currentUser)) {
            Map<String, String> userProfile = userProfiles.get(currentUser);
            nameField.setText(userProfile.get("fullName"));
            emailField.setText(userProfile.get("email"));
            phoneField.setText(userProfile.get("phone"));
            addressField.setText(userProfile.get("address"));
        }
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        
        JButton saveButton = createStyledButton("Save Changes", new Color(40, 167, 69));
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validate fields
                if (nameField.getText().trim().isEmpty() || 
                    emailField.getText().trim().isEmpty() || 
                    phoneField.getText().trim().isEmpty() || 
                    addressField.getText().trim().isEmpty()) {
                    
                    JOptionPane.showMessageDialog(dashboardFrame, 
                        "Please fill in all fields.", 
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Update user profile
                Map<String, String> userProfile = userProfiles.get(currentUser);
                userProfile.put("fullName", nameField.getText().trim());
                userProfile.put("email", emailField.getText().trim());
                userProfile.put("phone", phoneField.getText().trim());
                userProfile.put("address", addressField.getText().trim());
                
                // Save user profiles
                saveUserProfiles();
                
                // Log activity
                logActivity("Updated profile information");
                
                // Show success message
                JOptionPane.showMessageDialog(dashboardFrame, 
                    "Profile updated successfully!", 
                    "Profile Updated", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        JButton changePasswordButton = createStyledButton("Change Password", new Color(0, 123, 255));
        changePasswordButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showChangePasswordDialog();
            }
        });
        
        buttonPanel.add(saveButton);
        buttonPanel.add(changePasswordButton);
        formPanel.add(buttonPanel, gbc);
        
        // Center the form
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        centerPanel.add(formPanel);
        
        panel.add(centerPanel, BorderLayout.CENTER);
        
        return panel;
    }
    
    /**
     * Convert USD to INR
     * @param usdAmount String representing USD amount (e.g., "$45/day" or "$225")
     * @return String representing the equivalent amount in INR
     */
    private String convertToRupees(String usdAmount) {
        try {
            // Extract the numeric value from the string
            String numericPart = usdAmount.replace("$", "").replace("/day", "").replace(",", "").trim();
            double usdValue = Double.parseDouble(numericPart);
            
            // Convert to INR
            double inrValue = usdValue * USD_TO_INR_RATE;
            
            // Format the result
            String formattedInr = String.format("₹%.2f", inrValue);
            
            // Add "/day" suffix if the original had it
            if (usdAmount.contains("/day")) {
                formattedInr += "/day";
            }
            
            return formattedInr;
        } catch (Exception e) {
            // Return original if conversion fails
            return usdAmount;
        }
    }
    
    /**
     * Show change password dialog
     */
    private void showChangePasswordDialog() {
        // Create a custom dialog
        JDialog passwordDialog = new JDialog(dashboardFrame, "Change Password", true);
        passwordDialog.setSize(400, 300);
        passwordDialog.setLocationRelativeTo(dashboardFrame);
        passwordDialog.setLayout(new BorderLayout());
        
        // Create a form panel
        JPanel formPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create glass effect with gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 220),
                    0, getHeight(), new Color(240, 240, 255, 220)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Title
        JLabel titleLabel = new JLabel("Change Password", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);
        
        // Current password
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel currentLabel = new JLabel("Current Password:");
        currentLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(currentLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JPasswordField currentField = createStyledPasswordField(15);
        formPanel.add(currentField, gbc);
        
        // New password
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel newLabel = new JLabel("New Password:");
        newLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(newLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JPasswordField newField = createStyledPasswordField(15);
        formPanel.add(newField, gbc);
        
        // Confirm password
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel confirmLabel = new JLabel("Confirm Password:");
        confirmLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(confirmLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JPasswordField confirmField = createStyledPasswordField(15);
        formPanel.add(confirmField, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        
        JButton saveButton = createStyledButton("Save Password", new Color(40, 167, 69));
        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get password values
                String currentPassword = new String(currentField.getPassword());
                String newPassword = new String(newField.getPassword());
                String confirmPassword = new String(confirmField.getPassword());
                
                // Validate fields
                if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(passwordDialog, 
                        "Please fill in all password fields.", 
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Check if current password is correct (for demo, we'll use "password")
                if (!currentPassword.equals("password")) {
                    JOptionPane.showMessageDialog(passwordDialog, 
                        "Current password is incorrect.", 
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Check if new passwords match
                if (!newPassword.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(passwordDialog, 
                        "New password and confirmation do not match.", 
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                // Update password in user profile
                Map<String, String> userProfile = userProfiles.get(currentUser);
                userProfile.put("password", newPassword);
                
                // Save user profiles
                saveUserProfiles();
                
                // Log activity
                logActivity("Changed password");
                
                // Show success message
                JOptionPane.showMessageDialog(passwordDialog, 
                    "Password changed successfully!", 
                    "Password Changed", JOptionPane.INFORMATION_MESSAGE);
                
                passwordDialog.dispose();
            }
        });
        
        JButton cancelButton = createStyledButton("Cancel", new Color(220, 53, 69));
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                passwordDialog.dispose();
            }
        });
        
        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);
        formPanel.add(buttonPanel, gbc);
        
        passwordDialog.add(formPanel, BorderLayout.CENTER);
        passwordDialog.setVisible(true);
    }
    
    /**
     * Show rental history dialog
     */
    private void showRentalHistoryDialog() {
        // Create a custom dialog
        JDialog historyDialog = new JDialog(dashboardFrame, "Rental History", true);
        historyDialog.setSize(600, 400);
        historyDialog.setLocationRelativeTo(dashboardFrame);
        historyDialog.setLayout(new BorderLayout());
        
        // Create a panel with a semi-transparent background
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create glass effect with gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 220),
                    0, getHeight(), new Color(240, 240, 255, 220)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Title
        JLabel titleLabel = new JLabel("Complete Rental History", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        
        // Log activity
        logActivity("Viewed rental history");
        
        // Create a table model
        String[] columns = {"Rental ID", "Car", "Start Date", "End Date", "Total Cost (USD)", "Total Cost (INR)", "Status"};
        
        // Get user's rental history
        java.util.List<Map<String, String>> userHistory = new ArrayList<>();
        for (Map<String, String> rental : rentalHistory) {
            if (rental.get("user").equals(currentUser)) {
                userHistory.add(rental);
            }
        }
        
        // Create data array
        Object[][] data;
        if (userHistory.isEmpty()) {
            // Default data if no history
            data = new Object[1][7];
            data[0] = new Object[]{"", "No rental history", "", "", "", "", ""};
        } else {
            data = new Object[userHistory.size()][7];
            for (int i = 0; i < userHistory.size(); i++) {
                Map<String, String> rental = userHistory.get(i);
                data[i] = new Object[]{
                    rental.get("rentalId"),
                    rental.get("carName"),
                    rental.get("startDate"),
                    rental.get("endDate"),
                    rental.get("totalCost"),
                    rental.get("totalCostInr"),
                    rental.get("status")
                };
            }
        }
        
        JTable table = new JTable(data, columns);
        table.setFont(new Font("Arial", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setGridColor(new Color(200, 200, 200));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        
        // Add a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        // Add a button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        JButton closeButton = createStyledButton("Close", new Color(108, 117, 125));
        closeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                historyDialog.dispose();
            }
        });
        
        JButton exportButton = createStyledButton("Export History", new Color(0, 123, 255));
        exportButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Export rental history to CSV file
                String exportFile = DATA_DIR + "/rental_history_" + currentUser + ".csv";
                exportRentalHistory(exportFile);
                
                JOptionPane.showMessageDialog(historyDialog, 
                    "Rental history exported successfully to:\n" + exportFile, 
                    "Export Complete", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        JButton printButton = createStyledButton("Print History", new Color(25, 135, 84));
        printButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Log activity
                logActivity("Printed rental history");
                
                JOptionPane.showMessageDialog(historyDialog, 
                    "Printing rental history...\n\n" +
                    "This is a simulated print function.", 
                    "Print", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        buttonPanel.add(exportButton);
        buttonPanel.add(printButton);
        buttonPanel.add(closeButton);
        
        // Add components to main panel
        mainPanel.add(titleLabel, BorderLayout.NORTH);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        historyDialog.add(mainPanel, BorderLayout.CENTER);
        historyDialog.setVisible(true);
    }
    
    /**
     * Show dialog for renting a car
     */
    private void showRentCarDialog(String carId, String carName, String dailyRate) {
        // Create a custom dialog
        JDialog rentDialog = new JDialog(dashboardFrame, "Rent a Car", true);
        rentDialog.setSize(400, 350);
        rentDialog.setLocationRelativeTo(dashboardFrame);
        rentDialog.setLayout(new BorderLayout());
        
        // Create a form panel
        JPanel formPanel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Create glass effect with gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, new Color(255, 255, 255, 220),
                    0, getHeight(), new Color(240, 240, 255, 220)
                );
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
                
                g2d.dispose();
                super.paintComponent(g);
            }
        };
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Title
        JLabel titleLabel = new JLabel("Rent a Car", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        formPanel.add(titleLabel, gbc);
        
        // Car details
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        JLabel carLabel = new JLabel("Car:");
        carLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(carLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        JLabel carValueLabel = new JLabel(carName + " (" + carId + ")");
        carValueLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(carValueLabel, gbc);
        
        // Daily rate
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel rateLabel = new JLabel("Daily Rate:");
        rateLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(rateLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        JLabel rateValueLabel = new JLabel(dailyRate + " (" + convertToRupees(dailyRate) + ")");
        rateValueLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        formPanel.add(rateValueLabel, gbc);
        
        // Start date
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel startLabel = new JLabel("Start Date:");
        startLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(startLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        JTextField startField = createStyledTextField(15);
        startField.setText(java.time.LocalDate.now().toString());
        formPanel.add(startField, gbc);
        
        // End date
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel endLabel = new JLabel("End Date:");
        endLabel.setFont(new Font("Arial", Font.BOLD, 14));
        formPanel.add(endLabel, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        JTextField endField = createStyledTextField(15);
        endField.setText(java.time.LocalDate.now().plusDays(5).toString());
        formPanel.add(endField, gbc);
        
        // Button panel
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.setOpaque(false);
        
        JButton confirmButton = createStyledButton("Confirm Rental", new Color(40, 167, 69));
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Validate dates
                String startDate = startField.getText().trim();
                String endDate = endField.getText().trim();
                
                if (startDate.isEmpty() || endDate.isEmpty()) {
                    JOptionPane.showMessageDialog(rentDialog, 
                        "Please enter both start and end dates.", 
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                try {
                    java.time.LocalDate start = java.time.LocalDate.parse(startDate);
                    java.time.LocalDate end = java.time.LocalDate.parse(endDate);
                    
                    if (end.isBefore(start)) {
                        JOptionPane.showMessageDialog(rentDialog, 
                            "End date cannot be before start date.", 
                            "Validation Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    
                    // Calculate rental duration and cost
                    long days = java.time.temporal.ChronoUnit.DAYS.between(start, end);
                    String rate = dailyRate.replace("$", "").replace("/day", "");
                    double dailyRateValue = Double.parseDouble(rate);
                    double totalCost = dailyRateValue * days;
                    
                    // Show confirmation
                    // Calculate INR cost
                    double totalCostInr = totalCost * USD_TO_INR_RATE;
                    
                    // Create rental record
                    Map<String, String> rental = new HashMap<>();
                    rental.put("rentalId", "R" + String.format("%03d", rentalHistory.size() + 1));
                    rental.put("carId", carId);
                    rental.put("carName", carName);
                    rental.put("startDate", startDate);
                    rental.put("endDate", endDate);
                    rental.put("days", String.valueOf(days));
                    rental.put("totalCost", "$" + String.format("%.2f", totalCost));
                    rental.put("totalCostInr", "₹" + String.format("%.2f", totalCostInr));
                    rental.put("status", "Active");
                    rental.put("user", currentUser);
                    rental.put("rentalDate", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
                    
                    // Add to active rentals
                    activeRentals.add(rental);
                    
                    // Add to rental history
                    rentalHistory.add(rental);
                    
                    // Save data
                    saveActiveRentals();
                    saveRentalHistory();
                    
                    // Log activity
                    logActivity("Rented car: " + carName + " (" + carId + ")");
                    
                    JOptionPane.showMessageDialog(rentDialog, 
                        "Car rental confirmed!\n\n" +
                        "Rental ID: " + rental.get("rentalId") + "\n" +
                        "Car: " + carName + " (" + carId + ")\n" +
                        "Period: " + startDate + " to " + endDate + "\n" +
                        "Duration: " + days + " days\n" +
                        "Total Cost: $" + String.format("%.2f", totalCost) + " / ₹" + String.format("%.2f", totalCostInr), 
                        "Rental Confirmed", JOptionPane.INFORMATION_MESSAGE);
                    
                    rentDialog.dispose();
                    
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(rentDialog, 
                        "Invalid date format. Please use YYYY-MM-DD format.", 
                        "Validation Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        JButton cancelButton = createStyledButton("Cancel", new Color(220, 53, 69));
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rentDialog.dispose();
            }
        });
        
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        formPanel.add(buttonPanel, gbc);
        
        rentDialog.add(formPanel, BorderLayout.CENTER);
        rentDialog.setVisible(true);
    }
    
    /**
     * Initialize default cars
     */
    private void initializeDefaultCars() {
        availableCars = new ArrayList<>();
        
        // Add default cars
        addDefaultCar("C001", "Toyota", "Camry", "2023", "Silver", "$45/day");
        addDefaultCar("C002", "Honda", "Accord", "2022", "Black", "$42/day");
        addDefaultCar("C003", "Ford", "Mustang", "2023", "Red", "$65/day");
        addDefaultCar("C004", "Chevrolet", "Malibu", "2022", "Blue", "$40/day");
        addDefaultCar("C005", "Nissan", "Altima", "2023", "White", "$43/day");
        addDefaultCar("C006", "BMW", "3 Series", "2022", "Black", "$75/day");
        addDefaultCar("C007", "Mercedes", "C-Class", "2023", "Silver", "$78/day");
        addDefaultCar("C008", "Audi", "A4", "2022", "Gray", "$72/day");
        
        // Save to file
        saveAvailableCars();
    }
    
    /**
     * Add a default car to the available cars list
     */
    private void addDefaultCar(String id, String make, String model, String year, String color, String rate) {
        Map<String, String> car = new HashMap<>();
        car.put("id", id);
        car.put("make", make);
        car.put("model", model);
        car.put("year", year);
        car.put("color", color);
        car.put("rate", rate);
        car.put("status", "Available");
        availableCars.add(car);
    }
    
    /**
     * Initialize default user
     */
    private void initializeDefaultUser() {
        userProfiles = new HashMap<>();
        
        // Add default user
        Map<String, String> defaultUser = new HashMap<>();
        defaultUser.put("fullName", "John Doe");
        defaultUser.put("email", "john.doe@example.com");
        defaultUser.put("phone", "(555) 123-4567");
        defaultUser.put("address", "123 Main St, Anytown, USA");
        defaultUser.put("password", "password");
        
        userProfiles.put("admin", defaultUser);
        
        // Save to file
        saveUserProfiles();
    }
    
    /**
     * Load available cars from file
     */
    @SuppressWarnings("unchecked")
    private boolean loadAvailableCars() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(AVAILABLE_CARS_FILE))) {
            availableCars = (java.util.List<Map<String, String>>) ois.readObject();
            System.out.println("Loaded " + availableCars.size() + " available cars");
            return true;
        } catch (Exception e) {
            System.out.println("Could not load available cars: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Save available cars to file
     */
    private boolean saveAvailableCars() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(AVAILABLE_CARS_FILE))) {
            oos.writeObject(availableCars);
            System.out.println("Saved " + availableCars.size() + " available cars");
            return true;
        } catch (Exception e) {
            System.out.println("Could not save available cars: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Load rental history from file
     */
    @SuppressWarnings("unchecked")
    private boolean loadRentalHistory() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(RENTAL_HISTORY_FILE))) {
            rentalHistory = (java.util.List<Map<String, String>>) ois.readObject();
            System.out.println("Loaded " + rentalHistory.size() + " rental history records");
            return true;
        } catch (Exception e) {
            System.out.println("Could not load rental history: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Save rental history to file
     */
    private boolean saveRentalHistory() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(RENTAL_HISTORY_FILE))) {
            oos.writeObject(rentalHistory);
            System.out.println("Saved " + rentalHistory.size() + " rental history records");
            return true;
        } catch (Exception e) {
            System.out.println("Could not save rental history: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Load active rentals from file
     */
    @SuppressWarnings("unchecked")
    private boolean loadActiveRentals() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ACTIVE_RENTALS_FILE))) {
            activeRentals = (java.util.List<Map<String, String>>) ois.readObject();
            System.out.println("Loaded " + activeRentals.size() + " active rentals");
            return true;
        } catch (Exception e) {
            System.out.println("Could not load active rentals: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Save active rentals to file
     */
    private boolean saveActiveRentals() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ACTIVE_RENTALS_FILE))) {
            oos.writeObject(activeRentals);
            System.out.println("Saved " + activeRentals.size() + " active rentals");
            return true;
        } catch (Exception e) {
            System.out.println("Could not save active rentals: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Load user profiles from file
     */
    @SuppressWarnings("unchecked")
    private boolean loadUserProfiles() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(USER_PROFILES_FILE))) {
            userProfiles = (Map<String, Map<String, String>>) ois.readObject();
            System.out.println("Loaded " + userProfiles.size() + " user profiles");
            return true;
        } catch (Exception e) {
            System.out.println("Could not load user profiles: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Save user profiles to file
     */
    private boolean saveUserProfiles() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USER_PROFILES_FILE))) {
            oos.writeObject(userProfiles);
            System.out.println("Saved " + userProfiles.size() + " user profiles");
            return true;
        } catch (Exception e) {
            System.out.println("Could not save user profiles: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Export rental history to CSV file
     */
    private void exportRentalHistory(String filePath) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
            // Write CSV header
            writer.println("Rental ID,Car,Start Date,End Date,Total Cost (USD),Total Cost (INR),Status,Rental Date,Return Date");
            
            // Write rental data
            for (Map<String, String> rental : rentalHistory) {
                if (rental.get("user").equals(currentUser)) {
                    writer.println(
                        rental.get("rentalId") + "," +
                        rental.get("carName") + "," +
                        rental.get("startDate") + "," +
                        rental.get("endDate") + "," +
                        rental.get("totalCost") + "," +
                        rental.get("totalCostInr") + "," +
                        rental.get("status") + "," +
                        rental.get("rentalDate") + "," +
                        (rental.containsKey("returnDate") ? rental.get("returnDate") : "")
                    );
                }
            }
            
            // Log activity
            logActivity("Exported rental history to " + filePath);
            
            System.out.println("Rental history exported to: " + filePath);
        } catch (Exception e) {
            System.out.println("Error exporting rental history: " + e.getMessage());
        }
    }
    
    /**
     * Save all data to files
     */
    private void saveAllData() {
        saveAvailableCars();
        saveActiveRentals();
        saveRentalHistory();
        saveUserProfiles();
        
        System.out.println("All data saved successfully");
    }
    
    /**
     * Log activity to file
     */
    private void logActivity(String activity) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ACTIVITY_LOG_FILE, true))) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String timestamp = dateFormat.format(new Date());
            String logEntry = timestamp + " - " + (currentUser != null ? currentUser : "Guest") + " - " + activity;
            
            writer.println(logEntry);
            System.out.println("Logged activity: " + logEntry);
        } catch (Exception e) {
            System.out.println("Could not log activity: " + e.getMessage());
        }
    }
    
    /**
     * Main method
     */
    public static void main(String[] args) {
        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        // Create and show GUI
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SimpleImageGUI();
            }
        });
    }
}